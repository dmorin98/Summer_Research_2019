/*********************************************************************************************
*		APP_SUPP.C		   Copyright (c) 1999 Gage Applied Sciences Inc.					 *
*																							 * 
* 	    Version 1.00.00	 - 07/15/99  - First Rivision										 *		
*      	Version 1.01.00  - 20/10/99  - Fixed the display of minor version while displaying   *
*									   DLL version.                                          *
*								     - Replace BoardTypeSizeToText with                      *
*									   gage_board_type_size_to_text routine.                 *
*									 - Added support for CS1602                              * 
*       Version 1.02.00	 - 17/1/2000 - Added support for CS3200	               				 *
\********************************************************************************************/

#define	STRICT

#include <io.h>
#include <direct.h>
#include "whichdrv.h"
#include <FCNTL.H>
#include <SYS\STAT.H>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "gage_drv.h"
#include "eeprom.h"
#include "app_supp.h"
#include "structs.h"
#include "structs.c"

#ifndef _WIN32
#include "timers.h"
#else
#define timing(x) Sleep(x/10)
#endif

 
/****************************\
*                           *
*       GLOBAL DEFINITIONS. *
*       =================== *
*                           *
\***************************/

char    str[512];       /*  Miscellaneous uses.  */
char	str1[256];
char	driver_version_str[256];
int16	boards_in_system;
uInt16 far				gage_board_location[GAGE_B_L_BUFFER_SIZE];
gage_driver_info_type   *board_info;

int16   external_clock_in_use = 0;
float	external_clock_rate = 0.0F;
int16	mul_record_available = 0;
int16	use_multiple_record = 0; 
int32	number_of_groups = -1;
int16	use_independent_mode = 0;

int16	use_invert_clock = 0;
int16	flag_3200 = 0;	

/*-------------------------------------------------------------------------*/

void    SetDefaultBoardLocation (uInt16 seg, uInt16 ind)
{
/*	This routine is used to set a default memory segment and I/O address
	for the board(s) found if the configuration file, GAGESCOPE.INC, is
	not found.  Used mainly for ISA boards.
*/
	int16             i;

	gage_set_records ((uInt16 far *)gage_board_location, 0, seg, ind, 0, 0);
	for (i = 1 ; i < GAGE_B_L_MAX_CARDS ; i++)
		gage_set_records ((uInt16 far *)gage_board_location, i, 0, 0, 0, 0);

}       /*      End of SetDefaultBoardLocation ().  */


/*----------------------------------------------------------------------------------------*/

int		InitBoard (void)
{
/*	Initializes all the CompuScope boards found in the system.  The routine
	attempts to read the GAGESCOP.INC configuration file to find out the memory
	segment and I/O addresses of the boards. The routine also updates several tables
	and structures depending upon the board type that is found.
*/
	uInt16						major_version, minor_version, board_support;
	int32						gdi_size;
	gage_driver_info_type far 	*gdi;
	int16						enable;
	char						config_filename[200];
	int 						ret;
	int16						i;

    config_filename[0] = '\0';
	ret = gage_get_config_filename ((LPSTR)(config_filename));
	if ((ret = gage_read_config_file ((LPSTR)(config_filename), (uInt16 far *)(gage_board_location))) < 0)  
	{
		wsprintf (str, "%s not found!", (LPSTR)config_filename);
		MessageBox(NULL, str, "Error", MB_OK);
		SetDefaultBoardLocation (0xd000, 0x0200);
	}

/*	For multiple board systems it is usually safer to call gage_driver_initialize twice.
	Not necessary for single board systems, but it does no harm.
*/	

	gage_driver_initialize((uInt16 far *)gage_board_location, GAGE_MEMORY_SIZE_TEST);
	if (!gage_driver_initialize((uInt16 far *)gage_board_location, GAGE_MEMORY_SIZE_TEST))  
	{
		wsprintf (str, "No CompuScope boards found!  Error code = %02x", (int16)(gage_board_location[GAGE_B_L_STATUS_START + 1]));
		MessageBox(NULL, str, "Error", MB_OK);
		return (1);
	}

	gage_get_driver_info_structure (&major_version, &minor_version, &board_support, &gdi, &gdi_size);

/*	Allocate memory to hold the board_info structure.  This ensures that if the
	size of the structure changes in the driver it won't affect the calling program.
*/	
	board_info = (gage_driver_info_type *)malloc(gdi_size);
	gage_get_driver_info(board_info);

	boards_in_system = gage_get_boards_found();


	if(use_independent_mode == 1)
	{
		for (i=1; i<=boards_in_system; i++)
		{
			gage_select_board(i);
			gage_get_driver_info(board_info);
			gage_board_type_size_to_text (str1, sizeof(str1), 1L, i, NULL, NULL, NULL, NULL);
			strcat(str1,"  ");
			strcat(str,str1);
		}
		wsprintf (driver_version_str, "\nCompuScope Driver Version   %d.%02d.%02d.\n", major_version, minor_version & 0xff, (minor_version >> 8) & 0xff);
		MessageBox(NULL, strcat(str,driver_version_str), "Success", MB_OK | MB_ICONINFORMATION);
	}
	else
	{
		gage_board_type_size_to_text (str, sizeof(str), 1L, 1L, NULL, NULL, NULL, NULL);
		wsprintf (driver_version_str, "\nCompuScope Driver Version   %d.%02d.%02d.\n", major_version, minor_version & 0xff, (minor_version >> 8) & 0xff);
		MessageBox(NULL, strcat(str,driver_version_str), "Success", MB_OK | MB_ICONINFORMATION);
	}
	
	gage_initialize_start_capture (1);

	if (use_independent_mode == 1)
	{
		for (i = 1; i<=boards_in_system; i++)
		{
			gage_select_board(i);
			gage_get_driver_info(board_info);
			
			/* Update tables in STRUCTS.C for specific versions and types of boards */
			update_sr_table_for_osc (board_info->board_version, board_info->board_type, board_info->ee_options);
			update_range_table_for_version (board_info->board_version, board_info->board_type, board_info->ee_options); 
	
			/* If you have an ets board but don't want to use ets, set enable to 0 */
			enable = gage_ets_detect ();
			update_sr_table_for_ets (enable, board_info->board_type);

			/* The gage_detect_multiple_record routine determines if a board is capable of multiple record captures. */
			mul_record_available = gage_detect_multiple_record();
	
			/* Set opmode for the first time.*/
			if ((board_info->board_type == GAGE_ASSUME_CS512) || (board_info->board_type == GAGE_ASSUME_CS1610))
				board.opmode = GAGE_DUAL_CHAN;
			if ((board_info->board_type == GAGE_ASSUME_CS1016) || (board_info->board_type == GAGE_ASSUME_CS8500))
				board.opmode = GAGE_SINGLE_CHAN;
		}
	}
	else
	{
		if (gage_select_board(1)!=1)  
		{
			MessageBox(NULL, "Error while selecting board!", "Error", MB_OK);
			return (2);
		}

		/* Update tables in STRUCTS.C for specific versions and types of boards */
    	update_sr_table_for_osc (board_info->board_version, board_info->board_type, board_info->ee_options);
		update_range_table_for_version (board_info->board_version, board_info->board_type, board_info->ee_options); 
	
		/* If you have an ets board but don't want to use ets, set enable to 0 */
		enable = gage_ets_detect ();
		update_sr_table_for_ets (enable, board_info->board_type);

		/*	The gage_detect_multiple_record routine determines if a board is capable of multiple record captures. */
		mul_record_available = gage_detect_multiple_record();
	
		/* Set opmode for the first time the window is drawn */
		if ((board_info->board_type == GAGE_ASSUME_CS512) || (board_info->board_type == GAGE_ASSUME_CS1610))
			board.opmode = GAGE_DUAL_CHAN;
		if ((board_info->board_type == GAGE_ASSUME_CS1016) || (board_info->board_type == GAGE_ASSUME_CS8500))
			board.opmode = GAGE_SINGLE_CHAN;
	}
	return (0);

}       /*  End of InitBoard ().  */

/*-------------------------------------------------------------------------*/

void    SetBoard (void)
{

/*	The SetBoard routine uses the board structure to pass the desired hardware
	parameters to the CompuScope board(s).	The routine handles both single board
	and multiple board master / slave configurations.  If any call fails, a message
	box is shown describing the error.
*/
	int16	i, ret;

	if (board.srindex == SRTI_EXTERNAL)
	{
		external_clock_in_use = 1;
		if (external_clock_rate == 0.0F)
			external_clock_rate = 10000000.0F;
	}

	if (external_clock_in_use)  
	{
		board.srindex = SRTI_EXTERNAL;
		gage_set_ext_clock_variables (board.opmode, (uInt16)-1, (float)external_clock_rate);
		sample_rate_table[SRTI_EXTERNAL].sr_calc = 1000000000.0F / external_clock_rate;
//		if (sample_rate_table[SRTI_EXTERNAL].sr_text != NULL)
//			free (sample_rate_table[SRTI_EXTERNAL].sr_text);
//		sample_rate_table[SRTI_EXTERNAL].sr_text = strdup (value_and_units_to_text ((double)(external_clock_rate), "Hz") + 1);	/*	Add 1 to skip the '+' sign.	*/
		strcpy (sample_rate_table[SRTI_EXTERNAL].sr_text,strdup (value_and_units_to_text ((double)(external_clock_rate), "Hz") + 1));	/*	Add 1 to skip the '+' sign.	*/
	}

	gage_get_driver_info (board_info);

	if ((board_info->board_type == GAGE_ASSUME_CS512) || (board_info->board_type == GAGE_ASSUME_CS1610))
		/* If CS512, force opmode to dual channel, single is invalid for 512. */
    	board.opmode = GAGE_DUAL_CHAN;

	if ((board_info->board_type == GAGE_ASSUME_CS1016) && (board_info->board_type != GAGE_ASSUME_CS1610))
	{
		/* If CS1016, force opmode to dual channel and range to +/- 1 volt.	*/
		board.opmode = GAGE_SINGLE_CHAN;
		board.range_a = board.range_b = GAGE_PM_1_V;
	}
	if (board_info->board_type == GAGE_ASSUME_CS8500)
		board.opmode = GAGE_SINGLE_CHAN;


/*	Enter the number of groups, if number of groups is equal to -1 
	means all the groups available.  In this case capture continues until
	the onboard memory is filled up.	*/ 

	if (mul_record_available == 1)
	{
		for (i = 1; i <= boards_in_system; i++)  
		{
			gage_select_board(i);
			if (use_multiple_record == 1)
			{
				gage_multiple_record(use_multiple_record);
				gage_multiple_record_acquisitions_32 (number_of_groups);
			}
			else
				gage_multiple_record(use_multiple_record);
		}
	}
	

	gage_select_board (1);	/* Select Master. */
	
	if (board_info->board_type == GAGE_ASSUME_CS3200)
	{
		if (external_clock_in_use == 1)
		{
			if (use_invert_clock == 1)
				flag_3200 = GAGE_CS3200_CLK_INVERT;
			else
				flag_3200 = 0x00;
		}
		if (!gage_capture_mode ((int16)(board.opmode | flag_3200), sample_rate_table[board.srindex].rate, sample_rate_table[board.srindex].mult))
		{
			wsprintf (str, "Error while setting capture mode!  Error Code = %d", gage_get_error_code ());
			MessageBox(NULL, str, "Error", MB_OK);
		}
	}
	else
	{
		if (!gage_capture_mode (board.opmode, sample_rate_table[board.srindex].rate, sample_rate_table[board.srindex].mult))
		{
			wsprintf (str, "Error while setting capture mode!  Error Code = %d", gage_get_error_code ());
			MessageBox(NULL, str, "Error", MB_OK);
		}
	}

    if (!gage_input_control (GAGE_CHAN_A, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
	{
		wsprintf (str, "Error while setting channel A input control in master!  Error Code = %d", gage_get_error_code ());
		MessageBox(NULL, str, "Error", MB_OK);
	}
	if (board.opmode == GAGE_SINGLE_CHAN)
	{
		if ((board_info->board_type != GAGE_ASSUME_CS8500) && (board_info->board_type != GAGE_ASSUME_CS3200))
		{
		/* CS8500 only has channel A. It doesn't hurt to set B, but this avoids the MessageBox */
			if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
			{
				wsprintf (str, "Error while setting channel B input control in master!  Error Code = %d", gage_get_error_code ());
				MessageBox(NULL, str, "Error", MB_OK);
			}
		}
	}else{
		if (board_info->board_type != GAGE_ASSUME_CS3200) {
			if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_b, (int16)(board.range_b | board.imped_b | board.diff_in_b)))
			{
				wsprintf (str, "Error while setting channel B input control in master!  Error Code = %d", gage_get_error_code ());
				MessageBox(NULL, str, "Error", MB_OK);
			}
		}
	}

	for (i = 2; i <= boards_in_system; i++)
	{
		gage_select_board (i);		/* Select slaves. */

		if ((board_info->board_type & (GAGE_ASSUME_CS1012 | GAGE_ASSUME_CS6012 | GAGE_ASSUME_CS512 | GAGE_ASSUME_CS8012)) && (board.srindex != SRTI_EXTERNAL))
		{
			if (!gage_capture_mode (board.opmode, sample_rate_table[board.srindex].rate, sample_rate_table[board.srindex].mult))
			{
				wsprintf (str, "Error setting capture mode on slave %d! Error code = %d", i, gage_get_error_code ());
				MessageBox (NULL, str, "Error", MB_OK);
			}
		}else{
			if (!gage_capture_mode (board.opmode, 0, GAGE_EXT_CLK))
			{
				wsprintf (str, "Error while setting EXT_CLK capture mode!  Error Code = %d", gage_get_error_code ());
				MessageBox(NULL, str, "Error", MB_OK);
			}
		}
		if (!gage_input_control (GAGE_CHAN_A, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
		{
			wsprintf (str, "Error while setting Channel A input control in slave! Error Code = %d", gage_get_error_code ());
			MessageBox (NULL, str, "Error", MB_OK);
		}
		if (board.opmode == GAGE_SINGLE_CHAN)
		{
			if (board_info->board_type != GAGE_ASSUME_CS8500)
			{
		/* CS8500 only has channel A. It doesn't hurt to set B, but this avoids the MessageBox */
				if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
				{
					wsprintf (str, "Error while setting channel A input control in slave!  Error Code = %d", gage_get_error_code ());
					MessageBox(NULL, str, "Error", MB_OK);
				}
			}
		}else{
			if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_b, (int16)(board.range_b | board.imped_b | board.diff_in_b)))
			{
				wsprintf (str, "Error while setting channel B input control in slave!  Error Code = %d", gage_get_error_code ());
				MessageBox(NULL, str, "Error", MB_OK);
			}
		}

		if (board_info->board_type & (GAGE_ASSUME_CS1016 | GAGE_ASSUME_CS6012 | GAGE_ASSUME_CS1012 | GAGE_ASSUME_CS512 | GAGE_ASSUME_CS8012))	/*	12 bit boards have 12 bit trigger levels.	*/
			ret = gage_trigger_control_2 (GAGE_SOFTWARE, GAGE_SOFTWARE, GAGE_DC, GAGE_PM_1_V, GAGE_POSITIVE, GAGE_POSITIVE, 0x7ff, 0x7ff, board.depth, 1, 1);
		else
			ret = gage_trigger_control_2 (GAGE_SOFTWARE, GAGE_SOFTWARE, GAGE_DC, GAGE_PM_1_V, GAGE_POSITIVE, GAGE_POSITIVE, 0x7f, 0x7f, board.depth, 1, 1);

		if (!ret)
		{
			wsprintf (str, "Error while setting trigger control in slave!  Error Code = %d", gage_get_error_code ());
			MessageBox(NULL, str, "Error", MB_OK);
		}

	}

	gage_select_board (1);	/* Select Master. */

	if (board_info->board_type & (GAGE_ASSUME_CS1016 | GAGE_ASSUME_CS6012 | GAGE_ASSUME_CS1012 | GAGE_ASSUME_CS512 | GAGE_ASSUME_CS8012))	/*	12 bit boards have 12 bit trigger levels.	*/
		ret = gage_trigger_control_2 (board.source, board.source_2, board.couple_e, board.range_e, board.slope, board.slope_2, (int16)(board.level << 4), (int16)(board.level_2 << 4), board.depth, 1, 1);
	else
		ret = gage_trigger_control_2 (board.source, board.source_2, board.couple_e, board.range_e, board.slope, board.slope_2, board.level, board.level_2, board.depth, 1, 1);

	if (!ret)
	{
		wsprintf (str, "Error while setting trigger control in master!  Error Code = %d", gage_get_error_code ());
		MessageBox(NULL, str, "Error", MB_OK);
	}

	if (mul_record_available == 1)
	{
		for (i = 1; i <= boards_in_system; i++)  
		{
			gage_select_board(i);
			if (use_multiple_record == 1)
				gage_multiple_record_acquisitions_32 (number_of_groups);
		}
	}
/*	Get the driver settings again so the values we have for mode, etc. are correct */
	gage_get_driver_info (board_info);

/* Let relays settle. */
	timing(100);

}       /*  End of SetBoard ().  */

/*------------------------------------------------------------------*/

int16   One_SetBoard (int16 board_no, int16	boards_in_system)
{

/*	The One_SetBoard routine uses the board structure to pass the 
	desired hardware parameters to the CompuScope board(s).	The 
	routine handles single boards. */

	int16	ret;

	gage_select_board(board_no);
	gage_get_driver_info (board_info);
	
	if (board.srindex == SRTI_EXTERNAL)
	{
		external_clock_in_use = 1;
		if (external_clock_rate == 0.0F)
			external_clock_rate = 10000000.0F;
	}

	if (external_clock_in_use)  
	{
		board.srindex = SRTI_EXTERNAL;
		gage_set_ext_clock_variables (board.opmode, (uInt16)-1, (float)external_clock_rate);
		sample_rate_table[SRTI_EXTERNAL].sr_calc = 1000000000.0F / external_clock_rate;
//		if (sample_rate_table[SRTI_EXTERNAL].sr_text != NULL)
//			free (sample_rate_table[SRTI_EXTERNAL].sr_text);
//		sample_rate_table[SRTI_EXTERNAL].sr_text = strdup (value_and_units_to_text ((double)(external_clock_rate), "Hz") + 1);	/*	Add 1 to skip the '+' sign.	*/
		strcpy (sample_rate_table[SRTI_EXTERNAL].sr_text, strdup (value_and_units_to_text ((double)(external_clock_rate), "Hz") + 1));	/*	Add 1 to skip the '+' sign.	*/
	}

	
	if ((board_info->board_type == GAGE_ASSUME_CS512) || (board_info->board_type == GAGE_ASSUME_CS1610))
		/* If CS512, force opmode to dual channel, single is invalid for 512. */
    	board.opmode = GAGE_DUAL_CHAN;

	if ((board_info->board_type == GAGE_ASSUME_CS1016) && (board_info->board_type != GAGE_ASSUME_CS1610))
	{
		/* If CS1016, force opmode to dual channel and range to +/- 1 volt.	*/
		board.opmode = GAGE_SINGLE_CHAN;
		board.range_a = board.range_b = GAGE_PM_1_V;
	}
	if (board_info->board_type == GAGE_ASSUME_CS8500)
		board.opmode = GAGE_SINGLE_CHAN;


/*	Enter the number of groups, if number of groups is equal to -1 
	means all the groups available.  In this case capture continues until
	the onboard memory is filled up.	*/ 

	if (mul_record_available == 1)
	{
		gage_select_board(board_no);
		if (use_multiple_record == 1)
		{
			gage_multiple_record(use_multiple_record);
			gage_multiple_record_acquisitions_32 (number_of_groups);
		}
		else
			gage_multiple_record(use_multiple_record);
	}
	
	if (!gage_capture_mode (board.opmode, sample_rate_table[board.srindex].rate, sample_rate_table[board.srindex].mult))
	{
		wsprintf (str, "Error while setting capture mode!  Error Code = %d", gage_get_error_code ());
		MessageBox(NULL, str, "Error", MB_OK);
	}

    if (!gage_input_control (GAGE_CHAN_A, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
	{
		wsprintf (str, "Error while setting channel A input control in master!  Error Code = %d", gage_get_error_code ());
		MessageBox(NULL, str, "Error", MB_OK);
	}
	if (board.opmode == GAGE_SINGLE_CHAN)
	{
		if (board_info->board_type != GAGE_ASSUME_CS8500)
		{
		/* CS8500 only has channel A. It doesn't hurt to set B, but this avoids the MessageBox */
			if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_a, (int16)(board.range_a | board.imped_a | board.diff_in_a)))
			{
				wsprintf (str, "Error while setting channel B input control in master!  Error Code = %d", gage_get_error_code ());
				MessageBox(NULL, str, "Error", MB_OK);
			}
		}
	}else{
	    if (!gage_input_control (GAGE_CHAN_B, GAGE_INPUT_ENABLE, board.couple_b, (int16)(board.range_b | board.imped_b | board.diff_in_b)))
		{
			wsprintf (str, "Error while setting channel B input control in master!  Error Code = %d", gage_get_error_code ());
			MessageBox(NULL, str, "Error", MB_OK);
		}
	}

	if (board_info->board_type & (GAGE_ASSUME_CS1016 | GAGE_ASSUME_CS6012 | GAGE_ASSUME_CS1012 | GAGE_ASSUME_CS512 | GAGE_ASSUME_CS8012))	/*	12 bit boards have 12 bit trigger levels.	*/
		ret = gage_trigger_control_2 (board.source, board.source_2, board.couple_e, board.range_e, board.slope, board.slope_2, (int16)(board.level << 4), (int16)(board.level_2 << 4), board.depth, 1, 1);
	else
		ret = gage_trigger_control_2 (board.source, board.source_2, board.couple_e, board.range_e, board.slope, board.slope_2, board.level, board.level_2, board.depth, 1, 1);

	if (!ret)
	{
		wsprintf (str, "Error while setting trigger control in master!  Error Code = %d", gage_get_error_code ());
		MessageBox(NULL, str, "Error", MB_OK);
	}

/*	Get the driver settings again so the values we have for mode, etc. are correct */
	gage_get_driver_info (board_info);

/* Let relays settle. */
	timing(100);
	return(1);

}       /*  End of One_SetBoard ().  */
