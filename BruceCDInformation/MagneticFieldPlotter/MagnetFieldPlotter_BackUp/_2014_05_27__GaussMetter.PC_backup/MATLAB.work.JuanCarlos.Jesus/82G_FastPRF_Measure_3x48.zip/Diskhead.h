/***********************************\
*	DISKHEAD.H		VERSION 3.00.	*
*									*
*	WRITTEN FOR BC31, MSC70, WC90.	*
*									*
*	COPYRIGHT (C) GAGE APPLIED		*
*	SCIENCES INC.			1998.	*
*									*
*	LAST UPDATE:		98/08/06.	*
\***********************************/

/***********************************\
*									*
*	Prevent multiple inclusions.	*
*									*
\***********************************/

#ifndef	__DISKHEAD_H__
#define	__DISKHEAD_H__

/*******************************************\
*											*
*	Memory Type definitions for DRIVERS.	*
*											*
\*******************************************/

#ifndef	__GAGE_MEMORY_TYPES__
#define	__GAGE_MEMORY_TYPES__
typedef	unsigned char	uInt8;
typedef	unsigned short	uInt16;
typedef	unsigned long	uInt32;
typedef	signed char		int8;
typedef	signed short	int16;
typedef	signed long		int32;
#ifndef	WINDOWS_CODE
#ifdef	_CVI_
typedef	char *			LPSTR;
#else
#ifdef	__WATCOMC__
typedef	char *			LPSTR;
#else
typedef	char far *		LPSTR;
#endif
#endif
#endif
#endif

/***********************************************************************\
*																		*
*	ADDITIONAL INCLUDE FILES REQUIRED FOR DISK FILE HEADER DEFINITIONS.	*
*																		*
\***********************************************************************/

#include	<limits.h>

/*******************************************************************\
*																	*
*	DISK FILE VERSIONS FOR GAGESCOPE SIGNAL FILES AND SETUP FILES.	*
*																	*
\*******************************************************************/

#define	FILE_VERSION_1		"GS V.1.20"
#define	FILE_VERSION_2		"GS V.2.00"
#define	FILE_VERSION_3		"GS V.2.05"
#define	FILE_VERSION_4		"GS V.2.10"
#define	FILE_VERSION_5		"GS V.2.15"
#define	FILE_VERSION_6		"GS V.2.20"
#define	FILE_VERSION_7		"GS V.2.25"
#define	FILE_VERSION_8		"GS V.2.50"
#define	FILE_VERSION_9		"GS V.2.60"
#define	FILE_VERSION_10		"GS V.2.65"
#define	FILE_VERSION_11		"GS V.2.70"
#define	FILE_VERSION_12		"GS V.2.75"
#define	FILE_VERSION_13		"GS V.2.80"
#define	FILE_VERSION_14		"GS V.2.85"
#define	FILE_VERSION_15		"GS V.2.95"
#define	FILE_VERSION_16		"GS V.3.00"
#define	FILE_VERSION		FILE_VERSION_16

/***********************************************************************\
*																		*
*	DISK FILE "multiple_record" is a bit maskable variable for a signed	*
*	16-bit integer.  Not all options are applicable to all boards or	*
*	files.  The default condition for this variable is zero.  This		*
*	maintains backward compatiblity with older files.					*
*																		*
\***********************************************************************/

/*		0        1         2         3	*/
/*		123456789012345678901234567890	*/

#define	MULREC_OPTION_NONE				0x0000
#define	MULREC_OPTION_HARDWARE			0x0001
#define	MULREC_OPTION_SOFTWARE			0x0002
#define	MULREC_OPTION_TALSBITS_APPEND	0x0004
//costa
#define	MULREC_OPTION_ETB_LEAD_GROUP	0x0008
#define	MULREC_OPTION_ETB_TRAIL_GROUP	0x0010
//PTM
#define MULREC_OPTION_PRE_TRIG_MULREC	0x0020

/***********************************************************************\
*																		*
*	DISK FILE "file_options" are bit maskable for an unsigned 32-bit	*
*	integer.  Not all options are applicable to all boards or files.	*
*	The default condition for this variable is zero.  This maintains	*
*	backward compatiblity with older files.								*
*																		*
\***********************************************************************/

/*		0        1         2         3	*/
/*		123456789012345678901234567890	*/

#define	FILE_OPTIONS_SINGLE_CAPTURE		0x00000001L
#define	FILE_OPTIONS_EXT_CLOCK_ADJUST	0x00000002L
#define	FILE_OPTIONS_MULREC_ADJUST		0x00000004L
#define	FILE_OPTIONS_REALTIME_MODE		0x00000008L

/***********************************************************************\
*																		*
*	DISK FILE "trigger_hardware" is a bit maskable variable for an		*
*	unsigned 32-bit integer.  Not all options are applicable to all		*
*	boards or files.  The default condition for this variable is zero.	*
*	This maintains backward compatiblity with older files.				*
*																		*
\***********************************************************************/

/*		0        1         2         3	*/
/*		123456789012345678901234567890	*/

#define	TRIGGER_HARDWARE_NONE			0x00000000L
#define	TRIGGER_HARDWARE_TMD_DATA		0x00000001L

/***********************************************************************\
*																		*
*	DISK FILE HEADER FOR ROUTINES TO TRANSFER TRACES TO / FROM DISK.	*
*																		*
\***********************************************************************/

#define	DISK_FILE_HEADER_SIZE	512
#define	DISK_FILE_FILEVERSIZE	14
#define	DISK_FILE_CHANNAMESIZE	9	/*	8 + NULL.  */
#define	DISK_FILE_COMMENT_SIZE	256
#define	DISK_FILE_MISC_SIZE		8
#define	DISK_FILE_SYSTEM_SIZE	40	/*  Note: data split into six areas.  */
#define	DISK_FILE_CHANNEL_SIZE	34	/*  Note: data split into three areas.  */
#define	DISK_FILE_DISPLAY_SIZE	34	/*  Note: data split into four areas.  */
#define	DISK_FILE_HEADER_PAD	(DISK_FILE_HEADER_SIZE - (DISK_FILE_FILEVERSIZE +	\
								DISK_FILE_CHANNAMESIZE + DISK_FILE_COMMENT_SIZE + 	\
								DISK_FILE_MISC_SIZE + DISK_FILE_SYSTEM_SIZE + 		\
								DISK_FILE_CHANNEL_SIZE + DISK_FILE_DISPLAY_SIZE))

#pragma pack (1)

typedef struct  {

	char	file_version[DISK_FILE_FILEVERSIZE];
	int16	crlf1;								/*	DISK_FILE_MISC_SIZE	*/
	char	name[DISK_FILE_CHANNAMESIZE];
	int16	crlf2;								/*	DISK_FILE_MISC_SIZE	*/
	char	comment[DISK_FILE_COMMENT_SIZE];
	int16	crlf3;								/*	DISK_FILE_MISC_SIZE	*/
	int16	control_z;							/*	DISK_FILE_MISC_SIZE	*/

	int16	sample_rate_index;					/*	DISK_FILE_SYSTEM_SIZE	*/
	int16	operation_mode;						/*	DISK_FILE_SYSTEM_SIZE	*/

#ifdef	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB

	uInt32	trigger_depth;						/*	DISK_FILE_SYSTEM_SIZE	*/

#else	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	int32	trigger_depth;						/*	DISK_FILE_SYSTEM_SIZE	*/

#endif	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	int16	trigger_slope;						/*	DISK_FILE_SYSTEM_SIZE	*/
	int16	trigger_source;						/*	DISK_FILE_SYSTEM_SIZE	*/
	int16	trigger_level;						/*	DISK_FILE_SYSTEM_SIZE	*/

#ifdef	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB

	uInt32	sample_depth;						/*	DISK_FILE_SYSTEM_SIZE	*/

#else	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	int32	sample_depth;						/*	DISK_FILE_SYSTEM_SIZE	*/

#endif	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	int16	captured_gain;						/*	DISK_FILE_CHANNEL_SIZE	*/
	int16	captured_coupling;					/*	DISK_FILE_CHANNEL_SIZE	*/
	int32	current_mem_ptr;					/*	DISK_FILE_CHANNEL_SIZE	*/
	int32	starting_address;					/*	DISK_FILE_CHANNEL_SIZE	*/
	int32	trigger_address;					/*	DISK_FILE_CHANNEL_SIZE	*/
	int32	ending_address;						/*	DISK_FILE_CHANNEL_SIZE	*/
	uInt16	trigger_time;						/*	DISK_FILE_CHANNEL_SIZE	*/
	uInt16	trigger_date;						/*	DISK_FILE_CHANNEL_SIZE	*/

	int16	trigger_coupling;					/*	DISK_FILE_SYSTEM_SIZE	*/
	int16	trigger_gain;						/*	DISK_FILE_SYSTEM_SIZE	*/

	int16	probe;								/*	DISK_FILE_CHANNEL_SIZE	*/

	int16	inverted_data;						/*  DISK_FILE_DISPLAY_SIZE  */
	uInt16	board_type;							/*  DISK_FILE_DISPLAY_SIZE  */
	int16	resolution_12_bits;					/*  DISK_FILE_DISPLAY_SIZE  */
												/*	Used when saving 12-bit data.	*/

	int16	multiple_record;					/*	DISK_FILE_SYSTEM_SIZE	*/
	int16	trigger_probe;						/*	DISK_FILE_SYSTEM_SIZE	*/

	int16	sample_offset;						/*  DISK_FILE_DISPLAY_SIZE  */
#ifdef	UNSIGNED_SAMPLE_RESOLUTION
	uInt16	sample_resolution;					/*  DISK_FILE_DISPLAY_SIZE  */
#else
	int16	sample_resolution;					/*  DISK_FILE_DISPLAY_SIZE  */
#endif
	int16	sample_bits;						/*  DISK_FILE_DISPLAY_SIZE  */

	uInt32	extended_trigger_time;				/*	DISK_FILE_CHANNEL_SIZE	*/
	int16	imped_a;							/*	DISK_FILE_CHANNEL_SIZE	*/
	int16	imped_b;							/*	DISK_FILE_CHANNEL_SIZE	*/

	float	external_tbs;						/*	DISK_FILE_SYSTEM_SIZE	*/
	float	external_clock_rate;				/*	DISK_FILE_SYSTEM_SIZE	*/

	uInt32	file_options;						/*	DISK_FILE_DISPLAY_SIZE	*/
	uInt16	version;							/*  DISK_FILE_DISPLAY_SIZE  */
	uInt32	eeprom_options;						/*  DISK_FILE_DISPLAY_SIZE  */

	uInt32	trigger_hardware;					/*	DISK_FILE_SYSTEM_SIZE	*/

	uInt32	record_depth;						/*  DISK_FILE_DISPLAY_SIZE  */
	int32	sample_offset_32;	 				/*  DISK_FILE_DISPLAY_SIZE  */
	int32	sample_resolution_32;				/*  DISK_FILE_DISPLAY_SIZE  */
	uInt16	multiple_record_count;				/*	DISK_FILE_SYSTEM_SIZE	*/

	uInt8	padding[DISK_FILE_HEADER_PAD];

} disk_file_header;

#pragma pack ()

/***********************************************\
*												*
*	GageScope file size structure used in the	*
*	channel saving code to vary the file size.	*
*												*
\***********************************************/

typedef struct  {
	int16	type;
	int32	max_pre_data;
	int32	max_post_data;
} filesizetype;

/***********************************************\
*												*
*	GageScope file size constants used in the	*
*	channel saving code to vary the file size.	*
*												*
\***********************************************/

#define	FST_NORMAL		0
#define	FST_SAVE_ALL	1
#define	FST_USER_DEF	2
#define	FST_TYPE_MAX	3
#define	FST_CURSORS		3
#define	FST_ALL			LONG_MAX

/***********************************************************************\
*																		*
*	GageScope signal file extra data block that is used for recording	*
*	the Pre-Trigger Multiple record trigger addresses and RAM FULL bits	*
*	at the end of the signal file.  The following structure is for the 	*
*	PTM mode of acquisition and is used by the drivers to correctly		*
*	allocate this block of memory for the application and itself.		*
*																		*
\***********************************************************************/

typedef struct {

	uInt32	Block_size;
	uInt32	Data_Start;
	uInt32	Type;
	uInt32	Block_Version;
	uInt32	NumOfBlks;
	uInt32	Element_size;

} ptm_data_header;

#define	PTM_HEADER_SIZE		(sizeof(ptm_data_header))
#define	PTM_HEADER_OFFSET	(sizeof(ptm_data_header)/sizeof(uInt32))

/***************\
*				*
*	Cleanup.	*
*				*
\***************/

#endif	/*	__DISKHEAD_H__	*/

/*	End of DISKHEAD.H.	*/
