/********************************************************\
*   GAGE_DRV.H	    VERSION 3.48.00						*
*                                                       *                                                       *
*   COPYRIGHT (C) GAGE APPLIED INC                      *
*	A Tektronix Technology Company                      *
*                                                       *
*	LAST UPDATE:		01/12/03                        *
\********************************************************/

#ifdef __WIN_95__
    #include "..\win95_98\stdvxd.h"
#endif

/*******************************************************\
*			    										*
*   IMPORTANT NOTE   IMPORTANT NOTE   IMPORTANT NOTE	*
*														*
*********************************************************
*														*
*   #include <windows.h> before #include "gage_drv.h"	*
*   when developing windows based applications.			*
*														*
*   #include "whichdrv.h" before #include "gage_drv.h"	*
*	    when the "whichdrv.h" file is required.			*
* 							  							*
\*******************************************************/

#ifndef __GAGE_DRV_H__

	#define __GAGE_DRV_H__

	#ifdef	__GAGESCOPE__
		#include	"\gage\gscope\whichdrv.h"
	#else
		#include	"whichdrv.h"
	#endif

/***********************************************\
*												*
*  Compiler in use and Target environment.		*
*												*
\***********************************************/

/*----------------------------------------------------------*/

/***********************\
*						*
*   DRIVER Version.		*
*						*
\***********************/

#define	GAGE_DRIVER_MAJOR_VERSION	3
#define	GAGE_DRIVER_MINOR_VERSION	48
#define	GAGE_DRIVER_SUB_VERSION		00

/*----------------------------------------------------------*/

/*	All global definitions of constants, variables and functions that
	are user usable and callable.  */
#ifndef TRUE
#define	TRUE	1
#define	FALSE	0
#endif

/*	CompuScope driver error codes.  These values are returned in
	the low byte of the error variable (gage_error_code).  The high
	byte contains the number of the board that caused the error.  */

#define GAGE_NO_ERROR				0x00
#define GAGE_NO_SUCH_BOARD			0x01
#define GAGE_NO_SUCH_MODE			0x02
#define GAGE_NO_SUCH_INPUT			0x03
#define GAGE_INVALID_SAMPLE_RATE	0x04
#define GAGE_NO_SUCH_COUPLING		0x05
#define GAGE_NO_SUCH_CHANNEL		0x06
#define GAGE_NO_SUCH_GAIN			0x07
#define GAGE_NO_SUCH_TRIG_DEPTH		0x08
#define GAGE_NO_SUCH_TRIG_POINT		0x09
#define GAGE_NO_SUCH_TRIG_SLOPE		0x0a
#define GAGE_NO_SUCH_TRIG_SOURCE	0x0b
#define GAGE_ROOT_CONFIG_FILE_BAD	0x0c
#define GAGE_INVALID_SYSTEM_FILE	0x0d
#define GAGE_SYSTEM_FILE_NOT_FOUND	0x0e
#define GAGE_NO_SUCH_SYSTEM			0x0f
#define GAGE_NO_SUCH_IMPEDANCE		0x10
#define GAGE_NO_SUCH_DIFF_INPUT		0x11

#define GAGE_MISC_ERROR				0xff

/*  CompuScope buffer size.  */

#define	GAGE_MAX_RAM_WINDOW			4096	/*  CompuScope area for RAM exchanges (8 bit cards).  */
#define	GAGE_16BIT_MAX_RAM_WINDOW	8192	/*  CompuScope area for RAM exchanges (16 bit cards).  */
#define	GAGE_DOUBLE_MAX_RAM_WINDOW	8192
#define	GAGE_DUAL_SHIFT_VALUE		12
#define	GAGE_DUAL_AND_VALUE			4095
#define	GAGE_SINGLE_SHIFT_VALUE		13
#define	GAGE_SINGLE_AND_VALUE		8191
#define	GAGE_DUAL_16BIT_SHIFT_VALUE		13
#define	GAGE_DUAL_16BIT_AND_VALUE		8191
#define	GAGE_SINGLE_16BIT_SHIFT_VALUE	14
#define	GAGE_SINGLE_16BIT_AND_VALUE		16383

/*  CompuScope channel and mode option values.  */

#define	GAGE_SINGLE_CHAN		0x01	/*	Mutually exclusive with GAGE_DUAL_CHAN.	*/
#define	GAGE_DUAL_CHAN			0x02	/*	Mutually exclusive with GAGE_SINGLE_CHAN.	*/
#define	GAGE_QUAD_CHAN			0x03	/*	4-byte sample	*/
#define	GAGE_MODE_EXT_CLK_ADJ	0x04	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust external clock
											trigger bits independantly of the sample
											rate (tbs).	*/
#define GAGE_MODE_MULREC_ADJUST 0x08	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust the data based
											on requirements for the multiple record
											trigger adjustment modification for the
											CS1012, CS6012, CS8012 and CS8012A.
											This will be a standard feature on
											the CS8012 and 8012A and the family
											based on this product.	*/
#define	GAGE_FAST_RAM_ADJUST	0x10	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust the data based
											on requirements for the fast memories
											used on the V2.0 CSx012 memory board.	*/
#define	GAGE_X012X_VERS_ADJUST	0x20	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust the data based
											on requirements for the GAL improvements
											used on the V2.0 CS8012 (et al) analog
											boards.	*/
#define	GAGE_VERSION_ADJUST		0x20	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust the data based
											on requirements for the V1.3 CS8500 analog
											boards.	*/
#define	GAGE_X1_CLOCK_ADJUST	0x40	/*	Can be ORed with either GAGE_DUAL_CHAN or
											GAGE_SINGLE_CHAN to adjust the data based
											on clock requirements for x1 dual mode data
											acquisition.	*/
#define GAGE_CS3200_CLK_INVERT	0x80	/*  Can be ORed with GAGE_SINGLE_CHAN, GAGE_DUAL_CHAN
											or GAGE_QUAD_CHAN. When ORed the CS3200 sample clock
											used will be inverted.	*/
#define GAGE_CS82G_FORCE_GRAY	0x100	/*  Can be ORed with GAGE_SINGLE_CHAN, GAGE_DUAL_CHAN
											or GAGE_QUAD_CHAN. When ORed the CS82G will use gray code 
											conversion	*/

#define GAGE_MODE_85_MEM_TEST	0x1000
#define GAGE_MODE_85_REAL_TIME	0x2000
#define GAGE_MODE_REAL_TIME		0x2000	/*	Generic version of the above define.	*/
#define GAGE_MODE_85_PRETRIG	0x4000
#define GAGE_MODE_85_PTM		(GAGE_MODE_85_PRETRIG | GAGE_SINGLE_CHAN)

#define	GAGE_MODE_OPTIONS		(GAGE_MODE_EXT_CLK_ADJ | GAGE_MODE_MULREC_ADJUST | GAGE_FAST_RAM_ADJUST | GAGE_X012X_VERS_ADJUST | GAGE_X1_CLOCK_ADJUST | GAGE_MODE_REAL_TIME)

/*  CompuScope trigger source values.  */

#define	GAGE_CHAN_A				1
#define	GAGE_CHAN_B				2
#define	GAGE_CH_A_CH_B			3
#define	GAGE_EXTERNAL			4
#define	GAGE_SOFTWARE			5
#define	GAGE_EXTERNAL_DIV_5		6	/*  Only available on the CS6012/CS1012.  */
#define	GAGE_EXTERNAL_TTL		7	/*  Only available on the CS512.  */

/*  CompuScope trigger delay operation values.  */
#define	GAGE_GET_DELAY_TIME				0
#define	GAGE_SET_DELAY_TIME				1
#define	GAGE_GET_DELAY_SAMPLES			2
#define	GAGE_SET_DELAY_SAMPLES 			3

/*	CompuScope channel input source values.  */

#define GAGE_INPUT_ENABLE		1					/*	Use with the CS1012, CS250 and CS220.  */
#define GAGE_INPUT_DISABLE		2					/*	Use with the CS1012, CS250 and CS220.  */
#define	GAGE_INPUT_DATA			GAGE_INPUT_ENABLE	/*	Use with the CSLITE.  */
#define	GAGE_INPUT_TEST			GAGE_INPUT_DISABLE	/*	Use with the CSLITE.  */

/*  CompuScope trigger type values.  */

#define	GAGE_DC					1
#define	GAGE_AC					2
#define GAGE_COUPLING_MASK      0x3;
#define GAGE_COUPLING_SPC       4

/*  CompuScope trigger slope values.  */

#define	GAGE_POSITIVE			1
#define	GAGE_NEGATIVE			2

/*  CompuScope trigger bandwidth values.  */ //nat 310700
#define	GAGE_FULL_BW			0
#define	GAGE_HIGH_REJECT		0x20
#define	GAGE_LOW_REJECT			0x40
#define	GAGE_NOISE_REJECT		0x60
#define	GAGE_TRIG_BW_EXPAND		0xE0	// not supported, future devt
#define	GAGE_BW_MASK			0xE0

/*  CompuScope trigger sensitivity values.  */ //nat 310700
#define	GAGE_SENSE_MASK				0xFF00
#define	GAGE_SENSE_SHIFT				8

/*  CompuScope sample rate multiplier values.  */

#define	GAGE_HZ					1
#define	GAGE_KHZ				2
#define	GAGE_MHZ				3
#define	GAGE_GHZ				4	/*  Used only with GAGE_RATE_1, GAGE_RATE_2 or GAGE_RATE_5 and CS2125.	*/
#define	GAGE_EXT_CLK			5
#define	GAGE_SW_CLK				6

/*  CompuScope sample rate rate values.  */

#define	GAGE_RATE_1				1
#define	GAGE_RATE_2				2
#define	GAGE_RATE_4				4
#define	GAGE_RATE_5				5
#define	GAGE_RATE_8				8
#define	GAGE_RATE_10			10
#define	GAGE_RATE_20			20
#define	GAGE_RATE_25			25		/*  Used only with GAGE_MHZ and CS250.  */
#define	GAGE_RATE_30			30		/*  Used only with GAGE_MHZ and CS6012.	*/
#define	GAGE_RATE_40			40		/*  Used only with GAGE_MHZ and CS8012, CSLITE or CS220.  */
#define	GAGE_RATE_50			50
#define	GAGE_RATE_60			60		/*  Used only with GAGE_MHZ and CS6012.	*/
#define	GAGE_RATE_65			65		/*  Used only with GAGE_MHZ for future use.	*/
#define	GAGE_RATE_80			80		/*  Used only with GAGE_MHZ and CS8012.  */
#define	GAGE_RATE_100			100
#define	GAGE_RATE_120			120		/*  Used only with GAGE_MHZ for future use.	*/
#define	GAGE_RATE_125			125		/*  Used only with GAGE_MHZ and CS2125.	*/
#define	GAGE_RATE_130			130		/*  Used only with GAGE_MHZ for future use.	*/
#define	GAGE_RATE_150			150		/*  Used only with GAGE_MHZ for future use.	*/
#define	GAGE_RATE_200			200
#define	GAGE_RATE_250			250		/*  Used only with GAGE_MHZ and CS2125.	*/
#define	GAGE_RATE_300			300		/*  Used only with GAGE_MHZ for future use.	*/
#define	GAGE_RATE_500			500
#define	GAGE_RATE_2500			2500	/*  Used only with GAGE_KHZ and CS1610.  */
#define	GAGE_RATE_12500			12500	/*  Used only with GAGE_KHZ and CS225.  */

/*  CompuScope ETS sample rate values.  */

#define	GAGE_ETS_250_MHZ		250	/*	CS2125 only.	*/
#define	GAGE_ETS_500_MHZ		500	/*	CS2125 only.	*/
#define	GAGE_ETS_1_GHZ			1	/*	Must match CS250_ETS_1_GHZ and driver code.	*/
#define	GAGE_ETS_2_GHZ			2	/*	Must match CS250_ETS_2_GHZ and driver code.	*/
#define	GAGE_ETS_4_GHZ			3	/*	Must match CS250_ETS_4_GHZ and driver code.	*/
#define	GAGE_ETS_USER			0	/*	Must match CS250_ETS_USER  and driver code.	*/

/*  CompuScope ETS capture types.  */

#define	GAGE_ETS_AVERAGES_MIN	3	/*	Minimum value.  CANNOT BE LESS THAN 3.  Sample each ETS delay number of times, discard min/max average middle.	*/
#define	GAGE_ETS_AVERAGES_INIT	7	/*	Initial value.  CANNOT BE LESS THAN 3.  Sample each ETS delay number of times, discard min/max average middle.	*/
#define	GAGE_ETS_AVERAGES_MAX	22	/*	Maximum value.  CANNOT BE LESS THAN 3.  Sample each ETS delay number of times, discard min/max average middle.	*/

/*  CompuScope Enhanced Input Board (EIB) input range values.  */

#define	GAGE_EIB_PM_FLAG		0x100					/*	EIB flag signifies that range passed to xxxx_input_control / xxxx_set_gain is an EIB range.	*/
														/*	Supported by Board:		CS2125	All other boards.	*/
#define	GAGE_EIB_PM_40_MV		(0x00|GAGE_EIB_PM_FLAG)	/*	+/- 40 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_50_MV		(0x01|GAGE_EIB_PM_FLAG)	/*	+/- 50 millivolts.		No		No		*/
#define	GAGE_EIB_PM_80_MV		(0x02|GAGE_EIB_PM_FLAG)	/*	+/- 80 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_100_MV		(0x03|GAGE_EIB_PM_FLAG)	/*	+/- 100 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_200_MV		(0x04|GAGE_EIB_PM_FLAG)	/*	+/- 200 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_400_MV		(0x05|GAGE_EIB_PM_FLAG)	/*	+/- 400 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_500_MV		(0x06|GAGE_EIB_PM_FLAG)	/*	+/- 500 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_800_MV		(0x07|GAGE_EIB_PM_FLAG)	/*	+/- 800 millivolts.		Yes		No		*/
#define	GAGE_EIB_PM_1_V			(0x08|GAGE_EIB_PM_FLAG)	/*	+/- 1 volts.			Yes		No		*/
#define	GAGE_EIB_PM_2_V			(0x09|GAGE_EIB_PM_FLAG)	/*	+/- 2 volts.			Yes		No		*/
#define	GAGE_EIB_PM_4_V			(0x0a|GAGE_EIB_PM_FLAG)	/*	+/- 4 volts.			Yes		No		*/
#define	GAGE_EIB_PM_5_V			(0x0b|GAGE_EIB_PM_FLAG)	/*	+/- 5 volts.			Yes		No		*/
#define	GAGE_EIB_PM_8_V			(0x0c|GAGE_EIB_PM_FLAG)	/*	+/- 8 volts.			Yes		No		*/
#define	GAGE_EIB_PM_10_V		(0x0d|GAGE_EIB_PM_FLAG)	/*	+/- 10 volts.			Yes		No		*/
#define	GAGE_EIB_PM_20_V		(0x0e|GAGE_EIB_PM_FLAG)	/*	+/- 20 volts.			Yes		No		*/
#define	GAGE_EIB_PM_40_V		(0x0f|GAGE_EIB_PM_FLAG)	/*	+/- 40 volts.			Yes		No		*/
//#define	GAGE_EIB_CUSTOM									/*	Custom configuration	Yes		No		*/
#define	GAGE_EIB_MAX_RANGES		0x10					/*	Used by CS2125 EIB code to access gain/offset values in "eib_dac_values" array.	*/
#define	GAGE_EIB_RANGE_MASK		0x000f					/*	All the EIB ranges will fit within this area of the input word (same as GAGE_RANGE_MASK).	*/

#define	GAGE_EIB_SINGLE_SWAPPED	0						/*	ADC A and ADC B get channel B input.	*/
#define	GAGE_EIB_SINGLE_NORMAL	1						/*	ADC A and ADC B get channel A input.	*/
#define	GAGE_EIB_DUAL_NORMAL	2						/*	ADC A and ADC B get channel A and channel B inputs respectfully.	*/
#define	GAGE_EIB_MODES			3						/*	Number of supported EIB modes.	*/

#define	GAGE_EIB_DACS			4						/*	Number of DACS required for each EIB mode.	*/

/*  CompuScope input range values.  */

#ifdef	ALLOW_CS8500_CODE_RANGES
									/*	Supported by Board:		CS8500	CS2125	CS265	CSx012	250/225	220		LITE.	*/
#define	GAGE_PM_10_V			0	/*	+/- 10 volts.			No		No		No		No		No		No		No		*/
#define	GAGE_PM_5_V				1	/*	+/- 5 volts.			Yes		Yes		Yes		Yes		Yes		Yes		No		*/
#define	GAGE_PM_4_V				2	/*	+/- 4 volts.			Yes		No		No		No		No		No		No		*/
#define	GAGE_PM_2_V				3	/*	+/- 2 volts.			Yes		Yes		Yes		Yes		No		Yes		No		*/
#define	GAGE_PM_1_V				4	/*	+/- 1 volts.			Yes		Yes		Yes		Yes		Yes		Yes		Yes		*/
#define	GAGE_PM_500_MV			5	/*	+/- 500 millivolts.		Yes		Yes		Yes		Yes		Yes		Yes		No		*/
#define	GAGE_PM_400_MV			6	/*	+/- 400 millivolts.		Yes		No		No		No		No		No		No		*/
#define	GAGE_PM_200_MV			7	/*	+/- 200 millivolts.		Yes		Yes*	Yes		Yes		Yes		Yes		Yes		*/
#define	GAGE_PM_100_MV			8	/*	+/- 100 millivolts.		Yes		No		No		Yes		Yes		Yes		No		*/
#define	GAGE_STRAIGHT			9	/*	Straight to A/D input	Yes		No		No		No		No		No		No		*/
#define	GAGE_MAX_RANGES			10	/*	Used by CS2125 and CSx012 code to access gain/offset values in "dac_12_bit_values" array.	*/
									/*	Yes* : for CS2125 V2.0+ only.	*/

#else	/*	ALLOW_CS8500_CODE_RANGES	*/

									/*	Supported by Board:		CS1610	CS12130	CS12100	CS2125	CS265	CS1016	CSx012	250/225	220		LITE.	*/
#define	GAGE_PM_10_V			0	/*	+/- 10 volts.			Yes		No		No		No		No		No		No		No		No		No		*/
#define	GAGE_PM_5_V				1	/*	+/- 5 volts.			Yes		Yes		Yes		Yes		Yes		No		Yes		Yes		Yes		No		*/
#define	GAGE_PM_2_V				2	/*	+/- 2 volts.			Yes		Yes		Yes		Yes		Yes		Yes		Yes		No		Yes		No		*/
#define	GAGE_PM_1_V				3	/*	+/- 1 volts.			Yes		Yes		Yes		Yes		Yes		No		Yes		Yes		Yes		Yes		*/
#define	GAGE_PM_500_MV			4	/*	+/- 500 millivolts.		Yes		Yes		Yes		Yes		Yes		No		Yes		Yes		Yes		No		*/
#define	GAGE_PM_200_MV			5	/*	+/- 200 millivolts.		Yes		Yes		Yes		Yes*	Yes		No		Yes		Yes		Yes		Yes		*/
#define	GAGE_PM_100_MV			6	/*	+/- 100 millivolts.		Yes		Yes		Yes		No		No		No		Yes		Yes		Yes		No		*/
#if defined	ALLOW_CS1610_CODE_RANGES || defined ALLOW_CS85G_CODE_RANGES
#define	GAGE_PM_50_MV			7	/*	+/- 50 millivolts.		Yes		No		No		No		No		No		No		No		No		No		*/
#define	GAGE_MAX_RANGES			8	/*	Used by CS2125 and CSx012 code to access gain/offset values in "dac_12_bit_values" array.	*/
									/*	Yes* : for CS2125 V2.0+ only.	*/
#else	/*	ALLOW_CS1610_CODE_RANGES	*/
#define	GAGE_MAX_RANGES			7	/*	Used by CS2125 and CSx012 code to access gain/offset values in "dac_12_bit_values" array.	*/
									/*	Yes* : for CS2125 V2.0+ only.	*/
#endif	/*	ALLOW_CS1610_CODE_RANGES	*/
#endif	/*	ALLOW_CS8500_CODE_RANGES	*/

#ifdef ALLOW_CS85G_CODE_RANGES	/* for Raptor CS3052 only */
#define	GAGE_PM_50_V		8				/*	+/- 40 V		*/
#define	GAGE_PM_20_V		9				/*	+/- 20 V		*/
#define	GAGE_PM_20_MV		10				/*	+/- 25 mV		*/
#define	GAGE_PM_10_MV		11				/*	+/- 10 mV		*/
#define	GAGE_PM_5_MV		12				/*	+/- 5 mV		*/

#undef	GAGE_MAX_RANGES
#define	GAGE_MAX_RANGES		13
#endif	/* ALLOW_CS85G_CODE_RANGES */

#define	GAGE_RANGE_MASK			0x000f	/*	All the ranges will fit within this area of the input word.	*/

#define	GAGE_DAC_TABLE_SIZE		(8 * GAGE_MAX_RANGES)	/*	Row 0)	Single Channel mode		Channel A Range
															Row 1)	Single Channel mode		Channel A Offset
															Row 2)	Single Channel mode		Channel B Range
															Row 3)	Single Channel mode		Channel B Offset
															Row 4)	Dual Channel mode		Channel A Range
															Row 5)	Dual Channel mode		Channel A Offset
															Row 6)	Dual Channel mode		Channel B Range
															Row 7)	Dual Channel mode		Channel B Offset	*/
/*  CompuScope input impedance values.  */
										/*	Supported by Board:		CS1610	CS2125	CS8012v1.2	CS8012	CS6012	CS1012	250		220		LITE.	*/
#define	GAGE_1_MOHM_INPUT		0		/*	1 MOhm.					Yes		Yes		Yes			Yes		Yes		Yes		Yes		Yes		Yes		*/
#define	GAGE_50_OHM_INPUT		0x10	/*	50 Ohm.					Yes		Yes		Yes			No		No		No		No		No		No		*/
#define	GAGE_SINGLE_ENDED_INPUT	0		/*	Single ended input.		Yes		Yes		Yes			Yes		Yes		Yes		Yes		Yes		Yes		*/
#define	GAGE_DIFFERENTIAL_INPUT	0x80	/*	Differential input.		Yes		No		No			No		No		No		No		No		No		*/
#define	GAGE_IMPED_MASK			0x00f0	/*	All the impedances will fit within this area of the input word.	*/
#define	GAGE_IMPED_INPUT_MASK	0x00f0	/*	All the impedances will fit within this area of the input word.	*/

/*  Default CompuScope calibration filename.  */

#define	GAGE_DEFAULT_CALIB_FILENAME		"CALTABLE.DAC"

/*  CompuScope trigger point values.  */

#define	GAGE_POST_0K			0L
#define	GAGE_POST_128			128L
#define	GAGE_POST_256			256L
#define	GAGE_POST_512			512L
#define	GAGE_POST_1K			1024L
#define	GAGE_POST_2K			2048L
#define	GAGE_POST_4K			4096L
#define	GAGE_POST_8K			8192L
#define	GAGE_POST_16K			16384L
#define	GAGE_POST_32K			32768L
#define	GAGE_POST_64K			65536L
#define	GAGE_POST_128K			131072L
#define	GAGE_POST_256K			262144L
#define	GAGE_POST_512K			524288L
#define	GAGE_POST_1M			1048576L
#define	GAGE_POST_2M			2097152L
#define	GAGE_POST_4M			4194304L
#define	GAGE_POST_8M			8388608L
#define	GAGE_POST_16M			16777216L

/*  Multiple record functionality codes.  */

#define	GAGE_MR_ACQUIRE			1	/*	MR acquisition performed.	*/
#define	GAGE_MR_EXACT_FIT		2	/*	MR acq/file is exact fit, MR group size == acq depth.	*/
#define	GAGE_MR_TA_LSBITS		4	/*	MR acq has least significant trigger bits encoded and appended to data file or aux buffer.	*/
#define	GAGE_MR_EMBED_LSBITS	8	/*	MR acq has least significant trigger bits embedded into the acq/data file at raw TA for each group.	*/

/*  gage_acquire_average return codes.  */

#define	GAGE_AA_SUCCESSFUL				1L
#define	GAGE_AA_ROUTINE_UNAVAILABLE		0L
#define	GAGE_AA_INVALID_TRIGGER_SOURCE	-1L
#define	GAGE_AA_INVALID_TRIGGER_DEPTH	-2L
#define	GAGE_AA_INVALID_BUFFER_SIZES	-3L
#define	GAGE_AA_INVALID_CHANNEL			-4L
#define	GAGE_AA_UNAVAILABLE_CHANNEL		-5L
#define	GAGE_AA_INVALID_AVERAGE_NUM		-6L
#define	GAGE_AA_INVALID_SAMPLE_NUM		-7L
#define	GAGE_AA_TRIGGER_TIMEOUT			-8L
#define	GAGE_AA_BUSY_TIMEOUT			-9L

/*  gage_peak_detect return codes.  */

#define	GAGE_PD_SUCCESSFUL				1L
#define	GAGE_PD_ROUTINE_UNAVAILABLE		0L
#define	GAGE_PD_TRIGGER_TIMEOUT			-1L
#define	GAGE_PD_BUSY_TIMEOUT			-2L

// REALTIME_ISR
/*  REAL TIME Mode codes.  */
#define GAGE_RT_ENABLE					1L
#define GAGE_RT_DISABLE					-1L
#define GAGE_RT_SUSPEND					0L
#define GAGE_RT_STATUS					0x80000000
#define GAGE_RTS_FIFO_OVERFLOW			0x10L
#define	GAGE_RTS_TRIGGER				0x00000001
#define	GAGE_RTS_CAPTURED				0x00000002

/***************************************************************************\
*																			*
*	CompuScope gage_board_location structure.								*
*	=========================================								*
*																			*
*			GAGE_B_L_ELEMENT_SIZE		GAGE_B_L_STATUS_SIZE				*
*					 _|_						 _|_						*
*					/   \						/   \						*
*																			*
*	array index:	0	1	2	3	...	30	31	32	33	34	35	...	62	63	*
*																			*
*	meaning:		S1	I1	S2	I2	...	S16	I16	B1	E1	B2	E2	...	B16	E16	*
*												^							*
*												|							*
*												GAGE_B_L_STATUS_START		*
*																			*
*	where:			Sx = segment for board x,								*
*					Ix = index for board x,									*
*					Bx = returned board type for board x,					*
*					Ex = returned status error for board x.					*
*																			*
\***************************************************************************/

/*  CompuScope definitions for gage_board_location sizing.  */

#define	GAGE_B_L_MAX_CARDS		16
#define	GAGE_B_L_SIZEOF_ELEMENT	2
#define	GAGE_B_L_ELEMENT_SIZE	2
#define	GAGE_B_L_STATUS_SIZE	2
#define	GAGE_B_L_STATUS_START	(GAGE_B_L_MAX_CARDS * GAGE_B_L_ELEMENT_SIZE)
#define	GAGE_B_L_BUFFER_SIZE	(GAGE_B_L_MAX_CARDS * (GAGE_B_L_ELEMENT_SIZE + GAGE_B_L_STATUS_SIZE))

/*  CompuScope definitions for "gage_board_location" status errors.  */

#define	GAGE_BAD_LSB_SEGMENT			0x0001
#define	GAGE_BAD_MSB_SEGMENT			0x0002
#define	GAGE_BAD_LSB_INDEX				0x0004
#define	GAGE_BAD_MSB_INDEX				0x0008
#define	GAGE_DETECT_FAILED				0x0010
#define	GAGE_MEMORY_FAILED				0x0020
#define GAGE_BAD_MEMORY_SIZE			0x0040
#define	GAGE_ALLOC_FAILED				0x0080
#define	GAGE_PCI_MEM_EXPECTED			0x0100
#define	GAGE_PCI_MEM_LINK_FAILED		0x0200

#define	GAGE_ALL_NON_GAGE_STATUS_ERRORS	0x0000
#define	GAGE_ALL_GAGE_STATUS_ERRORS		(GAGE_BAD_LSB_SEGMENT | GAGE_BAD_MSB_SEGMENT | GAGE_BAD_LSB_INDEX \
										| GAGE_BAD_MSB_INDEX \
										| GAGE_DETECT_FAILED | GAGE_MEMORY_FAILED | GAGE_BAD_MEMORY_SIZE \
										| GAGE_ALLOC_FAILED | GAGE_PCI_MEM_EXPECTED | GAGE_PCI_MEM_LINK_FAILED)
#define	GAGE_ALL_STATUS_ERRORS			(GAGE_ALL_NON_GAGE_STATUS_ERRORS | GAGE_ALL_GAGE_STATUS_ERRORS)

/*	CompuScope definitions for "board_type" test override values and for
	"gage_board_location" status checks.  The CS2125 is included here for
	future use.  The CS25016 will also be released in the near future.	*/

#define	GAGE_ASSUME_NOTHING		0x0000
#define	GAGE_ASSUME_CS265		0x0001
#define	GAGE_ASSUME_CS8500		0x0002
#define	GAGE_ASSUME_CS8012_TYPE	0x0004
#define	GAGE_ASSUME_CS8012		0x0008
#define	GAGE_ASSUME_CSPCI		0x0010
#define	GAGE_ASSUME_CS512		0x0020
#define	GAGE_ASSUME_CS225		0x0040	/*	CS225:	Version ????.	*/
#define	GAGE_ASSUME_CSLITE11	0x0100	/*	Has been changed	*/
#define	GAGE_ASSUME_CS220		0x0200
#define	GAGE_ASSUME_CS250		0x0400	/*	Has been changed, (CS250 v 1.8 was 0x0080)	*/
#define	GAGE_ASSUME_CSLITE		0x0800	/*	Has been changed	*/
#define	GAGE_ASSUME_CSLITE15	0x0800	/*	Backward compatibility of the name only.	*/
#define	GAGE_ASSUME_CS1012		0x1000
#define	GAGE_ASSUME_CS6012		0x2000
#define	GAGE_ASSUME_CS2125		0x4000
#define	GAGE_ASSUME_CS1016		0x8000
#define GAGE_ASSUME_CS85G		(GAGE_ASSUME_CS8500 | 0x0001)	/*  Raptor use GAGE_ASSUME_CS265 */
#define	GAGE_ASSUME_CS3200		(GAGE_ASSUME_CS8500 | 0x0100)	/*	0x0100 is the old CSLITE.	*/
#define	GAGE_ASSUME_CS82G		(GAGE_ASSUME_CS8500 | 0x0080)	/*	0x0080 is the old CS25018.	*/
#define	GAGE_ASSUME_CS12100		(GAGE_ASSUME_CS8500 | GAGE_ASSUME_CS8012_TYPE | GAGE_ASSUME_CS8012)
#define	GAGE_ASSUME_CS12130		(GAGE_ASSUME_CS8500 | GAGE_ASSUME_CS8012_TYPE | GAGE_ASSUME_CS6012)
#define	GAGE_ASSUME_CS14100		(GAGE_ASSUME_CS8500 | GAGE_ASSUME_CS8012_TYPE | GAGE_ASSUME_CS1012)
#define	GAGE_ASSUME_CS1610		(GAGE_ASSUME_CS8500 | GAGE_ASSUME_CS8012_TYPE | GAGE_ASSUME_CS1016)
/*	#define	GAGE_ASSUME_RESERVED	0x8000	*/
#define	GAGE_ASSUME_ALL_BOARDS	(GAGE_ASSUME_CS265		| GAGE_ASSUME_CS8500		| \
								 GAGE_ASSUME_CS8012		| GAGE_ASSUME_CSPCI			| \
								 GAGE_ASSUME_CS512		| GAGE_ASSUME_CS225			| \
								 GAGE_ASSUME_CS82G		| GAGE_ASSUME_CS3200		| \
								 GAGE_ASSUME_CS220		| GAGE_ASSUME_CS250			| \
								 GAGE_ASSUME_CSLITE		| GAGE_ASSUME_CS1012		| \
								 GAGE_ASSUME_CS6012		| GAGE_ASSUME_CS2125		| \
								 GAGE_ASSUME_CS1016		| GAGE_ASSUME_CS8012_TYPE	| \
								 GAGE_ASSUME_CS12100	| GAGE_ASSUME_CS12130		| \
								 GAGE_ASSUME_CS14100	| GAGE_ASSUME_CS1610		)

/*  CompuScope definitions for memory test override values.  */

#define	GAGE_MEMORY_DEFAULT		((uInt16)(-1))
#define	GAGE_MEMORY_SIZE_TEST	0
#define	GAGE_MEMORY_SIZE_016K	16
#define	GAGE_MEMORY_SIZE_032K	32
#define	GAGE_MEMORY_SIZE_064K	64
#define	GAGE_MEMORY_SIZE_128K	128
#define	GAGE_MEMORY_SIZE_256K	256
#define	GAGE_MEMORY_SIZE_512K	512
#define	GAGE_MEMORY_SIZE_001M	1024
#define	GAGE_MEMORY_SIZE_002M	2048
#define	GAGE_MEMORY_SIZE_004M	4096
#define	GAGE_MEMORY_SIZE_008M	8192
#define	GAGE_MEMORY_SIZE_016M	16384

/*----------------------------------------------------------*/

/*  Definitions for gage_support_to_text.  */

#define	GAGE_GSTT_STR_SZ			80

/*  Definitions for gage_board_type_size_to_text.  */

#define	GAGE_GBTSTT_STR_SZ			30

#define	GAGE_GBTSTT_BOARD			0x01
#define	GAGE_GBTSTT_MEMORY			0x02
#define	GAGE_GBTSTT_BOTH			0x03
#define	GAGE_GBTSTT_LONG_NAME		0x04
#define	GAGE_GBTSTT_ALL_UPPER_CASE	0x08

/***********************************************************\
*															*
*	CompuScope specific definitions that need global scope.	*
*															*
\***********************************************************/

/*	CompuScope 32 bit cards.	*/
/*	========================	*/

#define	GAGE_UNSIGN_32_BIT_SAMPLE_OFFSET		0x7FFFFFFF
#define	GAGE_32_BIT_SAMPLE_OFFSET				-1
#define	GAGE_32_BIT_SAMPLE_RESOLUTION			2147483648U
#define	GAGE_32_BIT_SAMPLE_BITS					32

/*	CompuScope 16 bit cards.	*/
/*	========================	*/

#define	GAGE_UNSIGN_16_BIT_SAMPLE_OFFSET		0x7FFF		
#define	GAGE_16_BIT_SAMPLE_OFFSET				-1
#define	GAGE_16_BIT_SAMPLE_RESOLUTION			32768U
#define	GAGE_16_BIT_SAMPLE_BITS					16

/*	CompuScope 14 bit cards.	*/
/*	========================	*/

#define	GAGE_UNSIGN_14_BIT_SAMPLE_OFFSET		0x1FFF
#define	GAGE_14_BIT_SAMPLE_OFFSET				-1
#define	GAGE_14_BIT_SAMPLE_RESOLUTION			8192
#define	GAGE_14_BIT_SAMPLE_BITS					14


/*	CompuScope 12 bit cards.	*/
/*	========================	*/

#define	GAGE_UNSIGN_12_BIT_SAMPLE_OFFSET		0x7FF
#define	GAGE_12_BIT_SAMPLE_OFFSET				-1
#define	GAGE_12_BIT_SAMPLE_RESOLUTION			2048
#define	GAGE_12_BIT_SAMPLE_BITS					12

//cs1220 has only 7/8 of the codes
#define CS1220_SAMPLE_RESOLUTION 				1792


/*	CompuScope 8 bit cards.		*/
/*	=======================		*/

#define	GAGE_8_BIT_SAMPLE_OFFSET				127
#define	GAGE_8_BIT_SAMPLE_RESOLUTION			128
#define	GAGE_8_BIT_SAMPLE_BITS					8

/*	CompuScope 6012/1012/512.	*/
/*	=========================	*/

/*	Memory depths below 8 MB.	*/

#define	CS1012_TRIGGER_STEP_SIZE		6		/*  Size is 64 = 2**6.  */
#define	CS1012_TRIGGER_RES				64

/*	Memory depths 8 MB and above.	*/

#define	CS1012_TRIGGER_STEP_SIZE_8_16	7		/*  Size is 128 = 2**7.  */
#define	CS1012_TRIGGER_RES_8_16			128

/*----------------------------------------------------------*/

/*	CompuScope 12100         	*/
/*	=========================	*/

/*	Memory depths below 8 MB.	*/

#define	CS12100_TRIGGER_STEP_SIZE		6		/*  Size is 64 = 2**6.  */
#define	CS12100_TRIGGER_RES				64

/*	Memory depths 8 MB and above.	*/

#define	CS12100_TRIGGER_STEP_SIZE_8_16	7		/*  Size is 128 = 2**7.  */
#define	CS12100_TRIGGER_RES_8_16		128

/*----------------------------------------------------------*/

/*	CompuScope 82G.	*/
/*	================	*/

#define	CS82G_TRIGGER_STEP_SIZE		7		/*  Size is 128 = 2**7.  */
#define	CS82G_TRIGGER_RES			128

/*----------------------------------------------------------*/

/*	CompuScope 8500.	*/
/*	================	*/

#define	CS8500_TRIGGER_STEP_SIZE		6		/*  Size is 64 = 2**6.  */
#define	CS8500_TRIGGER_RES				64

/*----------------------------------------------------------*/

/*	CompuScope 2125.	*/
/*	================	*/

#define	CS2125_TRIGGER_STEP_SIZE		6		/*  Size is 64 = 2**6.  */
#define	CS2125_TRIGGER_RES				64

/*----------------------------------------------------------*/

/*	CompuScope 250/250v1.8/225.	*/
/*	===========================	*/

#define	CS250_TRIGGER_STEP_SIZE			6		/*  Size is 64 = 2**6.  */
#define	CS250_TRIGGER_RES				64

/*----------------------------------------------------------*/

/*	CompuScope 220.	*/
/*	===============	*/

#define	CS220_TRIGGER_STEP_SIZE			0
#define	CS220_TRIGGER_RES				0

/*----------------------------------------------------------*/

/*	CompuScope LITE.	*/
/*	================	*/

#define	CSLITE_TRIGGER_STEP_SIZE		4		/*  Size is 16 = 2**4.  */
#define	CSLITE_TRIGGER_RES				16

/*----------------------------------------------------------*/

/*	CompuScope 85G      				*/
/*	================					*/
/* Definitions of GPIB drivers's mode   */
#define GAGE_GPIB_DRIVER_DEFAULT_MODE 0
#define GAGE_GPIB_DRIVER_COMMAND_MODE 1

/*----------------------------------------------------------*/

/***************************************\
*										*
*	Global variables and structures.	*
*										*
\***************************************/

#ifdef _WIN32
#pragma pack (4)
#endif //_WIN32

typedef struct  {
	uInt16		index;
	uInt16		segment;
	uInt16		board_type;

#ifdef	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB

	uInt32		max_memory;
	uInt32		max_available_memory;

#else	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	int32		max_memory;
	int32		max_available_memory;

#endif	/*	USE_UNSIGNED_MEMORY_REQUIRED_FOR_DMB	*/

	uInt16		bank_offset_value;
	int16		mode;
	int16		enable_a;
	int16		enable_b;
	int16		rate;
	int16		multiplier;
	int16		coupling_a;
	int16		coupling_b;
	int16		coupling_ext;
	int16		gain_a;
	int16		gain_b;
	int16		gain_ext;
	int32		trigger_depth;
	int16		trigger_level;
	int16		trigger_slope;
	int16		trigger_source;
	int16		trigger_res;
	int16		multiple_recording;
	int16		sample_offset;
#ifdef	UNSIGNED_SAMPLE_RESOLUTION
	uInt16		sample_resolution;
#else
	int16		sample_resolution;
#endif
	int16		sample_bits;
	uInt16		external_clock_delay;
#if	defined(__WIN_NT__) || defined(__WIN_95__) || defined (__LINUX_KNL__)
	uInt32		external_clock_rate;
	uInt32		sample_rate;
#else
	float		external_clock_rate;
	float		sample_rate;
#endif
	void far	*memptr;
	int16		trigger_level_2;
	int16		trigger_slope_2;
	int16		trigger_source_2;
	int16		imped_a;
	int16		imped_b;
	uInt16		external_clock_adjust;
	int16		trigger_step;
	uInt16		board_version;
	uInt32		ee_options;
	uInt16		index_offset;
	int32		sample_offset_32;
	int32		sample_resolution_32;
	int16		diff_input_a;
	int16		diff_input_b;
	uInt32		multiple_record_count;
	uInt32		real_time_active;
	int16 		trigger_enable_control;

	// Compuscope Cs82G
	int16		trigger_sensitivity;
	int16		trigger_bandwidth;
	int16		trigger_sensitivity_2;
	int16		trigger_bandwidth_2;
	uInt16		max_trigger_sensitivity;
	uInt16		trigger_address_offset;
	uInt16		user_buffer_padding;
	int16		bus_master_support;
} gage_driver_info_type;

typedef struct _HIPRF_CHANNELS
{
	uInt16	Card;
	uInt16	Channel;
	void	*pBuffer;
} HIPRF_CHANNELS;


typedef struct _HIPRF_CHANNELS_LIST
{
	uInt32	Count;
	HIPRF_CHANNELS	pChannels[1];
} HIPRF_CHANNELS_LIST;


#ifdef _WIN32
#pragma pack ()
#endif //_WIN32

#ifdef	GAGE_DRIVER_SOURCE

/*	Variables required, declared allocated storage by the driver and
	available outside the driver to monitor the current state.  */

int16					gage_error_code = 0;
uInt16 far				gage_board_location[GAGE_B_L_BUFFER_SIZE];
int16					gage_boards_number;	/*	The number of the current active board.  */
int16					gage_all_boards_trigger = 0;
uInt16					gage_external_clock_delay = 0;
#if	defined(__WIN_NT__) || defined(__WIN_95__)|| defined (__LINUX_KNL__)
uInt32					gage_external_clock_rate = 1L;
#else
float					gage_external_clock_rate = 1.0F;
#endif
int32					gage_trigger_view_offset = 0L;	/*	-ve = pre trig, +ve = post_trig.	*/
gage_driver_info_type	gage_driver_info;

uInt16					gage_board_support =

#ifdef	ALLOW_CSLITE_CODE
						GAGE_ASSUME_CSLITE |
#endif
#ifdef	ALLOW_CS250_CODE
						GAGE_ASSUME_CS250 |
						GAGE_ASSUME_CS225 |
#endif
#ifdef	ALLOW_CS220_CODE
						GAGE_ASSUME_CS220 |
#endif
#ifdef	ALLOW_CS1012_CODE
						GAGE_ASSUME_CS512 |
						GAGE_ASSUME_CS1012 |
						GAGE_ASSUME_CS6012 |
						GAGE_ASSUME_CS8012 |
						GAGE_ASSUME_CS1016 |
#endif
#ifdef	ALLOW_CS12100_CODE
						GAGE_ASSUME_CS12100 |
						GAGE_ASSUME_CS1610 |
#endif
#ifdef	ALLOW_CS8500_CODE
						GAGE_ASSUME_CS8500 |
#endif
#ifdef	ALLOW_CS3200_CODE
						GAGE_ASSUME_CS3200 |
#endif
#ifdef	ALLOW_CSPCI_CODE
						GAGE_ASSUME_CSPCI |
#endif
#ifdef	ALLOW_CS2125_CODE
						GAGE_ASSUME_CS2125 |
						GAGE_ASSUME_CS265 |
#endif
						GAGE_ASSUME_NOTHING;

int16					gage_boards_found;	/*	The number of boards found during initialization.  */
int16					gage_ets_operation = 0;
uInt16					gage_delay_trigger = 0;
int16					gage_dsp_link_available = 0;
int16					gage_override_trigger_depth = 0;
int16					gage_force_calibration_flag = 0;	/*	Active HIGH.	*/
int16					gage_never_calibration_flag = 1;	/*	Active LOW.		*/
						
#ifdef	ALLOW_INDEPENDANT_OPERATION

int16					gage_independant_operation = 0;

#endif

#ifdef	DEBUG_TA

int32	debug_ta = 0;

#endif

/*	Variables used by the driver and only available to the driver.  */

static int16			gage_driver_initialized = FALSE;

#else

/*	DLL's can not have GLOBAL DATA. */

extern int16					gage_error_code;
extern uInt16 far				gage_board_location[];
extern int16					gage_boards_number;
extern int16					gage_all_boards_trigger;
extern uInt16					gage_external_clock_delay;
extern int16					gage_boards_found;
extern int32					gage_trigger_view_offset;
extern gage_driver_info_type	gage_driver_info;
extern uInt16					gage_board_support;
extern int16					gage_ets_operation;
extern uInt16					gage_delay_trigger;
extern int16					gage_dsp_link_available;
extern int16					gage_override_trigger_depth;
extern int16					gage_force_calibration_flag;	/*	Active HIGH.	*/
extern int16					gage_never_calibration_flag;	/*	Active LOW.		*/

#if	defined(__WIN_NT__) || defined(__WIN_95__)|| defined (__LINUX_KNL__)
	extern uInt32			gage_external_clock_rate;
#else
	extern float			gage_external_clock_rate;
#endif


#ifdef	ALLOW_INDEPENDANT_OPERATION

extern int16					gage_independant_operation;

#endif

#ifdef	DEBUG_TA

extern int32	debug_ta;

#endif
#endif

/*	OLD NAMES: For compatibility.
	-----------------------------	*/

/*  CompuScope gain values.	*/

#define	GAGE_DIVIDE_10			GAGE_PM_10_V
#define	GAGE_DIVIDE_5			GAGE_PM_5_V
#define	GAGE_DIVIDE_2			GAGE_PM_2_V
#define	GAGE_TIMES_1			GAGE_PM_1_V
#define	GAGE_TIMES_2			GAGE_PM_500_MV
#define	GAGE_TIMES_5			GAGE_PM_200_MV
#define	GAGE_TIMES_10			GAGE_PM_100_MV

/*	CompuScope definitions for "board_type".	*/

#define	GAGE_ASSUME_CS25016		GAGE_ASSUME_CS250	/*	CS250:	Version 1.6+, gcc->version is now used.	*/
#define	GAGE_ASSUME_CS25018		GAGE_ASSUME_CS250	/*	CS250:	Version 1.8+, gcc->version is now used.	*/

/*  CompuScope global routines.	*/

#define	gage_forced_trigger_capture						gage_force_capture
#define	gage_calculate_multiple_record_addresses		gage_calculate_mr_addresses
#define	gage_reset_interpolated_trigger					gage_reset_interpolate_trigger
#define	gage_get_interpolated_trigger					gage_get_interpolate_trigger
#define	gage_set_external_clock_variables				gage_set_ext_clock_variables
#define	gage_lv_calculate_multiple_record_addresses		gage_lv_calculate_mr_addresses
#define	gage_lv_set_ext_clock_variables					gage_lv_ext_clock_variables

/*	Special code generation controls.	*/

#define	GAGE_CMRA2_LOGICAL_BIT_ORDERING

/*----------------------------------------------------------*/

/*	Global MACRO routines.
	----------------------	*/

#define	GAGE_PTM_IN_USE(multiple_record)		((uInt16)(multiple_record) > 1)
#define	GAGE_PTM_RECORD_SIZE(multiple_record)	(1L << ((uInt32)(((multiple_record >> 8) + 1) & 0xff)))

/*----------------------------------------------------------*/

/*	Global routines: defined in the GAGE_DRV.C driver source file.
	--------------------------------------------------------------	*/

/*----------------------------------------------------------*/

#ifdef	__cplusplus

extern "C"	{

#endif

/*----------------------------------------------------------*/

/*	Routines to initialize the driver and CompuScope and select which
	CompuScope to control.  */

void  GAGEAPI	gage_make_error_code (uInt16 board, uInt16 error);
#ifdef	_WIN32
int16 GAGEAPI	gage_get_config_filename (char * cfgfn);
int16 GAGEAPI	gage_read_config_file (char * filename, uInt16 far *records);
#else	//_WIN32
int16 GAGEAPI	gage_get_config_filename (LPSTR cfgfn);
int16 GAGEAPI	gage_read_config_file (LPSTR filename, uInt16 far *records);
#endif //_WIN32
void  GAGEAPI   gage_set_gpib_driver_mode(uInt16 mode);
int16 GAGEAPI	gage_set_records (uInt16 far *records, int16 record, uInt16 segment, uInt16 index, uInt16 b_typename, uInt16 status);
int16 GAGEAPI	gage_get_records (uInt16 far *records, int16 record, uInt16 far *segment, uInt16 far *index, uInt16 far *b_typename, uInt16 far *status);
int16 GAGEAPI	gage_driver_initialize (uInt16 far *records, uInt16 memory);
void  GAGEAPI	gage_driver_remove (void);
int16 GAGEAPI	gage_select_board (int16 board);
int16 GAGEAPI	gage_get_boards_found(void);
int16 GAGEAPI	gage_get_error_code(void);

int16 GAGEAPI	gage_use_cal_table(int16 action);

int32 GAGEAPI	gage_get_trigger_address (void);
int32 GAGEAPI	gage_trigger_address (void);
void  GAGEAPI	gage_start_capture (int16 auto_trigger);
void  GAGEAPI	gage_initialize_start_capture (int16 hardware_to_use);
void  GAGEAPI	gage_abort_capture (int16 reset_trigger_source);
void  GAGEAPI	gage_force_capture (int16 reset_trigger_source);
int32 GAGEAPI	gage_lsbit_position (uInt32 value);
int32 GAGEAPI	gage_normalize_address (int32 start, int32 address, int32 ram_size);
int32 GAGEAPI	gage_addresses_valid (int32 start, int32 trig, int32 end, int32 ram_size, int16 far *ram_full_fail);
#if	defined(__WIN_95__) || defined(__WIN_NT__) || defined (__LINUX_KNL__)
void  GAGEAPI	gage_calculate_addresses (int16 chan, int16 op_mode, uInt32 tbs, int32 far *trig, int32 far *start, int32 far *end);
int32 GAGEAPI	gage_calculate_mr_addresses (int32 group, int16 board_type, int32 depth, int32 memory, int16 chan, int16 op_mode, uInt32 tbs, int32 far *trig, int32 far *start, int32 far *end);
int32 GAGEAPI	gage_calculate_mr_addresses_2 (int32 group, int16 board_type, int32 depth, int32 memory, int16 chan, int16 op_mode, uInt32 tbs, int32 far *trig, int32 far *start, int32 far *end,
											   int16 ta_lsbits_size, uInt8 far *ta_lsbits);
int32 GAGEAPI	gage_calculate_mra_addresses (int16 board_type, uInt16 version, int16 chan, int16 op_mode, uInt32 tbs, int32 far *trig, int32 far *start, int32 far *end, int16 data);
int32 GAGEAPI	gage_calculate_mr_addresses_4 (int32 group, uInt32 board_type, uInt16 trace_version, uInt32 eeprom_options, uInt32 depth, uInt32 RecordDepth, uInt32 memory, int32 chan, int32 op_mode, uInt32 tbs, 
											   uInt32 far *trig, uInt32 far *start, uInt32 far *end, uInt32 ex_data_size, void far *ex_data);
#else
void  GAGEAPI	gage_calculate_addresses (int16 chan, int16 op_mode, float tbs, int32 far *trig, int32 far *start, int32 far *end);
int32 GAGEAPI	gage_calculate_mr_addresses (int32 group, int16 board_type, int32 depth, int32 memory, int16 chan, int16 op_mode, float tbs, int32 far *trig, int32 far *start, int32 far *end);
int32 GAGEAPI	gage_calculate_mr_addresses_2 (int32 group, int16 board_type, int32 depth, int32 memory, int16 chan, int16 op_mode, float tbs, int32 far *trig, int32 far *start, int32 far *end,
											   int16 ta_lsbits_size, uInt8 far *ta_lsbits);
int32 GAGEAPI	gage_calculate_mra_addresses (int16 board_type, uInt16 version, int16 chan, int16 op_mode, float tbs, int32 far *trig, int32 far *start, int32 far *end, int16 data);
int32 GAGEAPI	gage_calculate_mr_addresses_4 (int32 group, uInt32 board_type, uInt16 trace_version, uInt32 eeprom_options, uInt32 depth, uInt32 RecordDepth, uInt32 memory, int32 chan, int32 op_mode, float tbs, 
											   uInt32 far *trig, uInt32 far *start, uInt32 far *end, uInt32 ex_data_size, void far *ex_data);
#endif

/*	Remember that ALL of the following routines work with the current
	selected board, as determined by "gage_select_board".  */

/*	Routines that configure a CompuScope board for the desired mode of
	operation and with the desired parameters.  */

int16 GAGEAPI	gage_capture_mode (int16 mode, int16 rate, int16 multiplier);
int16 GAGEAPI	gage_input_control (int16 channel, int16 enable, int16 coupling, int16 gain);
int16 GAGEAPI	gage_trigger_control (int16 source, int16 ext_coupling, int16 ext_gain, int16 slope, int16 level, int32 depth);
int16 GAGEAPI	gage_trigger_control_2 (int16 source_1, int16 source_2, int16 ext_coupling, int16 ext_gain, int16 slope_1, int16 slope_2, int16 level_1, int16 level_2, int32 depth, int16 trigger_from_bus, int16 trigger_to_bus);

/*	Routines that allow control over the CompuScope disabling and
	enabling data capturing, reading internal memory buffers and also
	getting the trigger addresses in the CompuScope to allow for
	repetious capture of signals.  */

void  GAGEAPI	gage_abort (void);
void  GAGEAPI	gage_get_data (void);
void  GAGEAPI	gage_need_ram (int16 need);
int16 GAGEAPI	gage_set_override_depth (int16 set);
int16 GAGEAPI	gage_mem_read_master (int32 location);
int16 GAGEAPI	gage_mem_read_dual (int16 channel, int32 location);
int16 GAGEAPI	gage_mem_read_chan_a (int32 location);
int16 GAGEAPI	gage_mem_read_chan_b (int32 location);
int16 GAGEAPI	gage_mem_read_single (int32 location);

/*	Routines that, under software control, activate normally automatic
	functions within the CompuScope for starting and performing data
	capture.  */

void  GAGEAPI	gage_software_clock (void);
void  GAGEAPI	gage_software_trigger (void);

/*	Routines to read back various control signals generated by the
	CompuScope to provide the application writer feedback from
	the current boards's operational state.  */

int16 GAGEAPI	gage_busy (void);
int16 GAGEAPI	gage_ram_full (void);
int16 GAGEAPI	gage_triggered (void);
int16 GAGEAPI	gage_triggered_aux (void);
int16 GAGEAPI	gage_read_master_status (void);
int16 GAGEAPI	gage_get_status (void);

/*	Routines to make use of CompuScope 250 and 2125 boards that support
	ETS (Equivalent Time Sampling).	*/

void  GAGEAPI	gage_ets_enable (int16 ets);
int16 GAGEAPI	gage_ets_detect (void);
void  GAGEAPI	gage_ets_trigger_speed (int16 fast_source);
void  GAGEAPI	gage_ets_set_rate (int16 ets_rate);
void  GAGEAPI	gage_ets_set_delay (int16 ets_delay);
void  GAGEAPI	gage_ets_mem_read_data (int32 location, uInt8 far *abuf, uInt8 far *bbuf);
void  GAGEAPI	gage_ets_capture (int16 auto_trigger, int32 timeout);
void  GAGEAPI	gage_ets_capture_2 (int16 auto_trigger, int32 timeout, uInt8 far *a_buffer, uInt8 far *b_buffer);
void  GAGEAPI	gage_ets_average_capture (int16 auto_trigger, int32 timeout, int16 avgs);
void  GAGEAPI	gage_ets_average_capture_2 (int16 auto_trigger, int32 timeout, int16 avgs, uInt8 far *a_buffer, uInt8 far *b_buffer);

/*	Routines used for real time capture.	*/

#ifdef DLLEXP
int32 GAGEAPI	gage_pci_rt_start_capture(void far * buffer, uInt32 record_sizeB, uInt32 padded, int16 auto_trigger, uInt32 *HowMany);
#else
int32 GAGEAPI	gage_pci_rt_start_capture(void far * buffer, uInt32 record_sizeB, uInt32 padded, int16 auto_trigger);
#endif

int32 GAGEAPI	gage_pci_rt_check_capture(void);
int32 GAGEAPI	gage_pci_rt_unpack (void far *packed_buf, void far *flat_buf, uInt32 size, uInt32 valid, uInt32 padded, uInt32 interleave);

/* Routines for interrupt and real time support */
// REALTIME_ISR
//#if		__8500_ISR_1_2__
uInt32 GAGEAPI   gage_rt_mode( uInt32 realtime_mode );
void  GAGEAPI	gage_attach_isr_func (int boardNum, void *pFunc, int event);
void  GAGEAPI	gage_detach_isr_func (int boardNum, int event);
void  GAGEAPI	gage_enable_isr(int event);
void  GAGEAPI	gage_disable_isr(int event);
void  GAGEAPI	gage_attach_isr_func_ex (int boardNum, void *pFunc, int event, uInt32 Timeout);
int16 GAGEAPI	gage_enable_interrupts ( int16 BoardNum );
int16 GAGEAPI	gage_disable_interrupts ( int16 BoardNum );
//#endif /* __8500_ISR_1_2__ */

/*----------------------------------------------------------*/

LPSTR GAGEAPI	gage_board_type_size_to_text (LPSTR string, uInt32 string_size, uInt32 action, uInt32 board, uInt32 far *bt, uInt32 far *eeopt, uInt32 far *ver, uInt32 far *max_mem);
LPSTR GAGEAPI	gage_support_to_text (LPSTR string, uInt32 string_size, uInt16 board_support);

/*----------------------------------------------------------*/

#ifdef	_CVI_

void  GAGEAPI	gage_get_driver_info (void far *gdi);

#else

void  GAGEAPI	gage_get_driver_info (gage_driver_info_type far *gdi);

#endif

/*	Global routines: group two, for application program use.
	--------------------------------------------------------	*/

/*	Routines that control how the memory buffers are accessed and located.  */

void  GAGEAPI	gage_set_trigger_res_step (int16 trigger_res, int16 trigger_step);
void  GAGEAPI	gage_set_block_number (uInt16 block);
void  GAGEAPI	gage_fast_set_block_number (uInt16 block);
void  GAGEAPI	gage_32k_to_buffer (uInt8 far *buffer, int16 high_half, int16 start_block, int16 far *blocks_transfered);
void  GAGEAPI	gage_get_trigger_view_offset (int32 far *offset);
void  GAGEAPI	gage_set_trigger_view_offset (int32 offset);
void  GAGEAPI	gage_trigger_view_transfer (int16 channel, uInt8 far *buffer, int16 nsamples);
void far* GAGEAPI gage_trigger_view_transfer_2 (int16 channel, void far *buffer, int32 nsamples);
void  GAGEAPI	gage_transfer_buffer (int32 ta, int16 channel, void far *buffer, int32 nsamples);
void far* GAGEAPI gage_transfer_buffer_2 (int32 ta, int16 channel, void far *buffer, int32 nsamples);
uInt32 GAGEAPI  gage_trigger_view_transfer_3 (int16 channel, void far *buffer, int32 nsamples);
uInt32 GAGEAPI  gage_transfer_buffer_3 (int32 ta, int16 channel, void far *buffer, int32 nsamples);

/*	Routines that handle miscellaneous functionality.  */

void  GAGEAPI	gage_init_clock (void);
void  GAGEAPI	gage_multiple_record_acquisitions (uInt16 number);
void  GAGEAPI	gage_multiple_record (uInt16 mode);
int16 GAGEAPI	gage_power_control (int16 mode);
void  GAGEAPI	gage_set_power (int16 mode);
int16 GAGEAPI	gage_read_cal_table (LPSTR caltable_name);
int16 GAGEAPI	gage_file_exists (LPSTR filename);
int16 GAGEAPI	gage_detect_multiple_record (void);
uInt32 GAGEAPI	gage_multiple_record_acquisitions_32 (uInt32 number);

#if __PTM_8500_1_2__
//PTM begin
int32 GAGEAPI 	gage_ptm_record_depth ( uInt32 record_size, void far **buffer );
void GAGEAPI	gage_ensure_pre_trigger_depth (uInt32 far *depth);
int32 GAGEAPI	gage_ptm_transfer (int16 far *channel, int32 far *group, void far *buffer, int32 far *pre_samples, int32 far *post_samples);
//PTM end
#endif /* PTM_CS8500_1_2 */

/*	Routines that handle interpolated trigger functionality.  */

void  GAGEAPI	gage_reset_interpolate_trigger (int16 board, int16 channel, int16 auto_mode, int16 level, int16 slope);
void  GAGEAPI	gage_get_interpolate_trigger (int16 action, int16 chan, int32 far *trig, int32 start, int32 end);

#ifdef	_CVI_

void  GAGEAPI	gage_get_driver_info_structure (uInt16 far *major_version, uInt16 far *minor_version, uInt16 far *board_support,
						void far * far * gdi, int32 far *gdi_size);
#else

void  GAGEAPI	gage_get_driver_info_structure (uInt16 far *major_version, uInt16 far *minor_version, uInt16 far *board_support,
						gage_driver_info_type far * far * gdi, int32 far *gdi_size);
#endif

int32 GAGEAPI   gage_hi_prf(unsigned char *bufPtr, unsigned long number, int32	timeout_ms);
int32 GAGEAPI   gage_hi_prf_2( unsigned char *bufPtr, HIPRF_CHANNELS_LIST *pChannelList, unsigned long NumOfAcq, int32 timeout_ms);

#if	defined(__WIN_95__) || defined(__WIN_NT__)|| defined (__LINUX_KNL__)
void  GAGEAPI	gage_set_ext_clock_variables (int16 op_mode, uInt16 external_clock_delay, uInt32 external_clock_rate);
#else
void  GAGEAPI	gage_set_ext_clock_variables (int16 op_mode, uInt16 external_clock_delay, float external_clock_rate);
#endif

void  GAGEAPI	gage_update_driver_info (void);

void  GAGEAPI	gage_get_min_max (int16 channel, int32 first, int32 nsamples, int16 far *min, int16 far *max);
void  GAGEAPI	gage_get_buffer_min_max (int16 channel, uInt8 far *buffer, int32 first, int16 nsamples, int16 *min, int16 *max);
int16 GAGEAPI	gage_min_max_test (int16 board_no);

/*----------------------------------------------------------*/

/*	Global routines: Special routines control Multiple Independant Operation.
	-------------------------------------------------------------------------	*/

#ifdef	ALLOW_INDEPENDANT_OPERATION

int16 GAGEAPI	gage_get_independant_operation (void);
void  GAGEAPI	gage_set_independant_operation (int16 independant);

void  GAGEAPI	gage_board_start_capture (int16 mi_board, int16 auto_trigger);
void  GAGEAPI	gage_board_abort_capture (int16 mi_board);
void  GAGEAPI	gage_board_force_capture (int16 mi_board);

#endif

/*----------------------------------------------------------*/

/*	Global routines: Special routines for LabVIEW development.
	----------------------------------------------------------	*/

void  GAGEAPI	gage_lv_calculate_addresses (int16 chan, int16 op_mode, float far *tbs, int32 far *trig, int32 far *start, int32 far *end);
int32 GAGEAPI	gage_lv_calculate_mr_addresses (int32 group, int16 board_type, int32 depth, int32 memory, int16 chan, int16 op_mode, float far *tbs, int32 far *trig, int32 far *start, int32 far *end);
void  GAGEAPI	gage_lv_ext_clock_variables (int16 op_mode, uInt16 external_clock_delay, float far *external_clock_rate);

/*----------------------------------------------------------*/

/*	Global routines: Special routines for extra functionality.
	----------------------------------------------------------	*/

uInt16 GAGEAPI	gage_set_delay_trigger (int16 action, uInt16 delay_trigger);
uInt32 GAGEAPI	gage_delay_trigger_32 (int16 action, uInt32* DelayLow,uInt32* DelayHigh);
void   GAGEAPI	gage_offset_adjust (int16 channel, int16 offset_adjust);

/*----------------------------------------------------------*/

/*	Global routines: Special routines for high level applications.
	--------------------------------------------------------------	*/

int32 GAGEAPI	gage_acquire_average (int16 channel, int32 nsamples, int32 naverages, int16 sum, int32 far *avg_buffer, void far *data_buffer, int32 data_buffer_size, int32 timeout);
int32 GAGEAPI	gage_peak_detect (void far *pd_buffer, void far *data_buffer, int32 trigger_timeout, int32 busy_timeout, int32 nsamples, void far *threshold_buffer);

/*----------------------------------------------------------*/

/*	Functions used for ARMADA project
	---------------------------------	*/

uInt32 GAGEAPI	cs2125_misc_control (int16 board, uInt32 control, uInt32 mask, uInt32 value);
int16  GAGEAPI	cs2125_input_offset (int16 chan, int16 offset);
void   GAGEAPI	cs2125_trigger_led (int16 led_on);
void   GAGEAPI	cs2125_swap_inputs (int16 swap_a_and_b);
int16  GAGEAPI  gage_eib_dac_adjust (void far *eeprom, int16 range, int16 channel, int16 off_gain, int16 adjust);

/*----------------------------------------------------------*/

int32 GAGEAPI	gage_gpib_command (char* strCommand, int nByteSize, char* rvBuffer, int nBufferSize);


#ifdef	__cplusplus

}

#endif

#endif //__GAGE_DRV_H__

/*----------------------------------------------------------*/

/*  End of GAGE_DRV.H.  */
