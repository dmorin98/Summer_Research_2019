/***********************************\
*	EEPROM.H		VERSION 3.00.	*
*									*
*	WRITTEN FOR BC31, MSC70, WC90.	*
*									*
*	COPYRIGHT (C) GAGE APPLIED		*
*	SCIENCES INC.			1998.	*
*									*
*	LAST UPDATE:		98/08/11.	*
\***********************************/

#ifndef __EEPROM_H__
#define __EEPROM_H__

/*----------------------------------------------------------*/

#define	EEPROM_4096_REQUIRED
#define	EEPROM_16384_REQUIRED

#define	ETS_IN_EEPROM
#define	nCLEAR_SERIAL_CONTROL
#define	nRESET_SERIAL_CONTROL

/*----------------------------------------------------------*/

/*	CompuScope EEPROM size and structure definitions.	*/

#define	EEPROM_SIGNATURE	"GAGE"

#define	DEFAULT_BOARD_EEPROM_VER_2125	0x0130
#define	DEFAULT_HWATI_EEPROM_VER_2125	0x0130
#define	DEFAULT_HWMEM_EEPROM_VER_2125	0x0121

#define	DEFAULT_BOARD_EEPROM_VER_8012	0x0300
#define	DEFAULT_HWATI_EEPROM_VER_8012	0x0000
#define	DEFAULT_HWMEM_EEPROM_VER_8012	0x0000

#define	DEFAULT_BOARD_EEPROM_VER_82G	0x0110	//nat070700
#define	DEFAULT_BOARD_EEPROM_VER_3200	0x0300	//nat040101

#define	DEFAULT_BOARD_EEPROM_VER_121X0	0x0110
#define	DEFAULT_HWATI_EEPROM_VER_121X0	0x0000
#define	DEFAULT_HWMEM_EEPROM_VER_121X0	0x0000

#define CS_EEPROM_REGISTERS_1024		64
#define CS_EEPROM_REGISTERS_4096		256
#define CS_EEPROM_REGISTERS_16384		1024

/*----------------------------------------------------------*/

/*	CompuScope EEPROM options encoding definitions.	*/

#define EEPROM_OPTIONS_MULTIPLE_REC		0x00000001L
#define EEPROM_OPTIONS_MASTER			0x00000002L
#define EEPROM_OPTIONS_SLAVE			0x00000004L
#define EEPROM_OPTIONS_ONE_CH_ONLY		0x00000008L
#define EEPROM_OPTIONS_TWO_CH_ONLY		0x00000010L
#define EEPROM_OPTIONS_NORMAL_OSC		0x00000020L
#define EEPROM_OPTIONS_MINMAX			0x00000040L
#define EEPROM_OPTIONS_INDEPEND_TRIG	0x00000080L
#define EEPROM_OPTIONS_PRE_TRIGGER		0x00000100L
#define EEPROM_OPTIONS_GATED_CAPTURE	0x00000200L
#define EEPROM_OPTIONS_SOFTWARE_CLOCK	0x00000400L
#define EEPROM_OPTIONS_EXTERNAL_CLOCK	0x00000800L
#define EEPROM_OPTIONS_ETS				0x00001000L
#define EEPROM_OPTIONS_CALIBRATED_DUAL	0x00002000L
#define EEPROM_OPTIONS_MULREC_ADJUST	0x00004000L
#define EEPROM_OPTIONS_DIRECT_INPUT		0x00008000L
#define EEPROM_OPTIONS_MULREC_COUNT		0x00010000L
#define EEPROM_OPTIONS_X1_CLOCK			0x00020000L
#define EEPROM_OPTIONS_DIM_SELECT_0		0x00040000L
#define EEPROM_OPTIONS_DIM_SELECT_1		0x00080000L
#define EEPROM_OPTIONS_DISABLE_CHANTRIG	0x00100000L
#define EEPROM_OPTIONS_EIB_CAPABLE		0x00200000L
#define EEPROM_OPTIONS_SPECIAL_MULREC	0x00400000L
#define EEPROM_OPTIONS_ALTERNATE_CONFIG	0x00800000L
#define EEPROM_OPTIONS_SINGLE_CALTABLE	0x01000000L
#define EEPROM_OPTIONS_DUAL_CALTABLE	0x02000000L
#define EEPROM_OPTIONS_ACTIVE_BRIDGE	0x04000000L
#define EEPROM_OPTIONS_PCI_MEMORY_ONLY	0x08000000L	/*	Only applies to the CP500 Class boards and base boards (CS82G).	*/
#define EEPROM_OPTIONS_UNDEFINED_B_28	0x10000000L
#define EEPROM_OPTIONS_UNDEFINED_B_29	0x20000000L
#define EEPROM_OPTIONS_CPCI_CARD		0x40000000L
#define EEPROM_OPTIONS_EXTENDED			0x80000000L

/*----------------------------------------------------------*/

#define EEPROM_OPTIONS_DIM_NONE			0x00000000L
#define EEPROM_OPTIONS_DIM_8			0x00040000L
#define EEPROM_OPTIONS_DIM_12_24		0x00080000L
#define EEPROM_OPTIONS_DIM_32			0x000c0000L
#define EEPROM_OPTIONS_DIM_MASK			0x000c0000L

/*----------------------------------------------------------*/

/*	CompuScope EEPROM version encoding definitions, these apply to the least significant nibble of the version number.	*/

#define	EEPROM_VERSION_CS2125_LSR	0x0001	/*	CS2125  support for Limited Sample Rates (no programmable oscillator).	*/
#define	EEPROM_VERSION_CS2125_SIR	0x0002	/*	CS2125  support for Shifted Input Ranges (ranges moved down by one).	*/

#define	EEPROM_VERSION_CS16XX_ESR	0x0001	/*	CS16XX  support for Extended Sample Rates.	*/
#define	EEPROM_VERSION_CS16XX_EDC	0x0002	/*	CS16XX  support for Extended Depth Count.	*/
#define	EEPROM_VERSION_CS16XX_EIR	0x0004	/*	CS16XX  support for Extended Input Ranges.	*/

#define	EEPROM_VERSION_CS12XX0_ESR	0x0001	/*	CS12XX0 support for Extended Sample Rates.	*/
#define	EEPROM_VERSION_CS12XX0_EDC	0x0002	/*	CS12XX0 support for Extended Depth Count.	*/

/*----------------------------------------------------------*/

/*	EEPROM indexes, these are in units of uInt16's.  This is how the EEPROM is organized.	*/

#define EEPROM_INDEX_SIGNATURE				0	/*	NOT null terminated.	*/
#define EEPROM_INDEX_SIZE					2	/*	Size of EEPROM in BITS.	*/
#define EEPROM_INDEX_BOARD_TYPE				3	/*	Encoded board types from GAGE_DRV.H.	*/
#define EEPROM_INDEX_VERSION				4	/*	BCD, XX.XX.	*/
#define EEPROM_INDEX_MEMORY_SIZE			5	/*	Decimal (in kilobytes).	*/
#define EEPROM_INDEX_SERIAL_NUMBER			6	/*	BCD, right-justified w/leading zeros.	*/
#define EEPROM_INDEX_OPTIONS				8	/*	BIT encoded (see EEPROM_OPTIONS_XXXXXXXX).	*/
#define EEPROM_INDEX_A_RANGES				10	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_A_OFFSETS				17	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_RANGES				24	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_OFFSETS				31	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_POWER_ON_VALUE			38	/*	Time in 0.1 mSecs for power on delay.	*/
#define EEPROM_INDEX_HW_ATI_VERSION			39	/*	BCD, XX.XX.	*/
#define EEPROM_INDEX_HW_MEM_VERSION			40	/*	BCD, XX.XX.	*/
#define EEPROM_INDEX_HW_ETS_VERSION			41	/*	BCD, XX.XX.	*/
#define EEPROM_INDEX_ETS_OFFSET				42	/*	Decimal.	*/
#define EEPROM_INDEX_ETS_CORRECT			43	/*	Decimal.	*/
#define EEPROM_INDEX_ETS_TRIGGER_OFFSET		44	/*	Decimal.	*/
#define EEPROM_INDEX_TRIG_LEVEL_OFF			45	/*	2 x uInt8, actually Decimal.	*/
#define EEPROM_INDEX_TRIG_LEVEL_SCALE		46	/*	2 x uInt8, actually Decimal.	*/
#define EEPROM_INDEX_TRIG_ADDR_OFF			47	/*	uInt4, 16 values in 4 words (layed out linearly -> 0,1,2,3 4,5,6,7 8,9,10,11 12,13,14,15) or	*/
												/*	uInt8,  8 values in 4 words (layed out linearly -> 0,1 2,3 4,5 6,7).	*/
#define EEPROM_INDEX_A_RANGE_50				51	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_A_OFFSET_50			52	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_RANGE_50				53	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_OFFSET_50			54	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_PADDING				55	/*	uInt16, zero filled.	*/
#define EEPROM_INDEX_1024_CHECK_SUM			63	/*	Check sum of entire 1K  EEPROM except these two bytes.  (location is NOT dependant on EEPROM size).	*/
#define EEPROM_INDEX_4096_CHECK_SUM			63	/*	Check sum of entire 4K  EEPROM except these two bytes.  (location is NOT dependant on EEPROM size).	*/
#define EEPROM_INDEX_16384_CHECK_SUM		63	/*	Check sum of entire 16K EEPROM except these two bytes.  (location is NOT dependant on EEPROM size).	*/
#define EEPROM_INDEX_A_RANGES_D				64	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_A_OFFSETS_D			71	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_RANGES_D				78	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_OFFSETS_D			85	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_A_RANGE_D_50			92	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_A_OFFSET_D_50			93	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_RANGE_D_50			94	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_B_OFFSET_D_50			95	/*	Default calibration values (all bits set if not supported).	*/
#define EEPROM_INDEX_PADDING_4096			96	/*	uInt16, zero filled.	*/
#define EEPROM_INDEX_EIB_DAC_AREA			160	/*	uInt8, 0x80 filled.	*/
#define EEPROM_INDEX_PADDING_16384			256	/*	uInt16, zero filled.	*/

#define EEPROM_INDEX_RANGE_OFFSET_SIZE		7	/*	7 x uInt16, organized differently for each board class.	*/

/*----------------------------------------------------------*/

typedef struct  {

	char	signature[4];		/*	NOT null terminated.	*/
	uInt16	size;				/*	Size of EEPROM in BITS.	*/
	uInt16	board_type;			/*	Encoded board types from GAGE_DRV.H.	*/
	uInt16	version;			/*	BCD, XX.XX.	*/
	uInt16	memory_size;		/*	Decimal (in kilobytes).	*/
	uInt32	serial_number;		/*	BCD, right-justified w/leading zeros.	*/
	uInt32	options;			/*	BIT encoded (see EEPROM_OPTIONS_XXXXXXXX).	*/
	uInt16	a_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	power_on_value;		/*	Time in 0.1 mSecs for power on delay.	*/
	uInt16	hw_ati_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_mem_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_ets_version;		/*	BCD, XX.XX.	*/
	uInt16	ets_offset;			/*	Decimal.	*/
	uInt16	ets_correct;		/*	Decimal.	*/
	uInt16	ets_trigger_offset;	/*	Decimal.	*/
	uInt8	trig_level_off[2];	/*	Decimal.	*/
	uInt8	trig_level_scale[2];/*	Decimal.	*/
	uInt16	trig_addr_off[4];	/*	uInt4, 16 values in 4 words (layed out linearly -> 0,1,2,3 4,5,6,7 8,9,10,11 12,13,14,15) or	*/
								/*	uInt8,  8 values in 4 words (layed out linearly -> 0,1 2,3 4,5 6,7).	*/
	uInt16	a_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	padding[8];			/*	Zero filled.	*/

/*#ifdef	ETS_IN_EEPROM*/
/*#else*/
/*	uInt16	padding[22];*/		/*	Zero filled.	*/
/*#endif*/
	uInt16	check_sum;			/*	Check sum of entire EEPROM except these two bytes.  (location is dependant on EEPROM size).	*/

#ifdef __linux__
}__attribute__ ((packed)) eepromtype1024;
#else

}eepromtype1024;
#endif

/*----------------------------------------------------------*/

typedef struct  {

	char	signature[4];		/*	NOT null terminated.	*/
	uInt16	size;				/*	Size of EEPROM in BITS.	*/
	uInt16	board_type;			/*	Encoded board types from GAGE_DRV.H.	*/
	uInt16	version;			/*	BCD, XX.XX.	*/
	uInt16	memory_size;		/*	Decimal (in kilobytes).	*/
	uInt32	serial_number;		/*	BCD, right-justified w/leading zeros.	*/
	uInt32	options;			/*	BIT encoded (see EEPROM_OPTIONS_XXXXXXXX).	*/
	uInt16	a_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	power_on_value;		/*	Time in 0.1 mSecs for power on delay.	*/
	uInt16	hw_ati_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_mem_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_ets_version;		/*	BCD, XX.XX.	*/
	uInt16	ets_offset;			/*	Decimal.	*/
	uInt16	ets_correct;		/*	Decimal.	*/
	uInt16	ets_trigger_offset;	/*	Decimal.	*/
	uInt8	trig_level_off[2];	/*	Decimal.	*/
	uInt8	trig_level_scale[2];/*	Decimal.	*/
	uInt16	trig_addr_off[4];	/*	uInt4, 16 values in 4 words (layed out linearly -> 0,1,2,3 4,5,6,7 8,9,10,11 12,13,14,15) or	*/
								/*	uInt8,  8 values in 4 words (layed out linearly -> 0,1 2,3 4,5 6,7).	*/
	uInt16	a_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	padding[8];			/*	Zero filled.	*/
	uInt16	check_sum;			/*	Check sum of entire EEPROM except these two bytes.  (location is NOT dependant on EEPROM size).	*/
	uInt16	a_ranges_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_ranges_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	padding_4096[64];	/*	Zero filled.	*/
	uInt8	eib_dac_area[192];	/*	0x80 filled.	*/

#ifdef __linux__
}__attribute__ ((packed)) eepromtype4096;

#else
}eepromtype4096;
#endif

/*----------------------------------------------------------*/

typedef struct  {

	char	signature[4];		/*	NOT null terminated.	*/
	uInt16	size;				/*	Size of EEPROM in BITS.	*/
	uInt16	board_type;			/*	Encoded board types from GAGE_DRV.H.	*/
	uInt16	version;			/*	BCD, XX.XX.	*/
	uInt16	memory_size;		/*	Decimal (in kilobytes).	*/
	uInt32	serial_number;		/*	BCD, right-justified w/leading zeros.	*/
	uInt32	options;			/*	BIT encoded (see EEPROM_OPTIONS_XXXXXXXX).	*/
	uInt16	a_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	power_on_value;		/*	Time in 0.1 mSecs for power on delay.	*/
	uInt16	hw_ati_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_mem_version;		/*	BCD, XX.XX.	*/
	uInt16	hw_ets_version;		/*	BCD, XX.XX.	*/
	uInt16	ets_offset;			/*	Decimal.	*/
	uInt16	ets_correct;		/*	Decimal.	*/
	uInt16	ets_trigger_offset;	/*	Decimal.	*/
	uInt8	trig_level_off[2];	/*	Decimal.	*/
	uInt8	trig_level_scale[2];/*	Decimal.	*/
	uInt16	trig_addr_off[4];	/*	uInt4, 16 values in 4 words (layed out linearly -> 0,1,2,3 4,5,6,7 8,9,10,11 12,13,14,15) or	*/
								/*	uInt8,  8 values in 4 words (layed out linearly -> 0,1 2,3 4,5 6,7).	*/
	uInt16	a_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	padding[8];			/*	Zero filled.	*/
	uInt16	check_sum;			/*	Check sum of entire EEPROM except these two bytes.  (location is NOT dependant on EEPROM size).	*/
	uInt16	a_ranges_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_d[7];		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_ranges_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	a_offsets_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_ranges_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	b_offsets_d_50;		/*	Default calibration values (all bits set if not supported).	*/
	uInt16	padding_4096[64];	/*	Zero filled.	*/
	uInt8	eib_dac_area[192];	/*	0x80 filled.	*/
//nat 070700	uInt16	padding_16384[768];	/*	Zero filled.	*/
	uInt16	padding_16384[588];	/*	Zero filled.	*/
//nat280700 
	uInt16	cal_trig_level[24];	/*	0x80 filled.	*/
	uInt16	cal_trig_addr[12];	/*	0x7F filled.	*/
	uInt16	cal_dac_area[144];	/*	0x80 filled.	*/

#ifdef __linux__
}__attribute__ ((packed)) eepromtype16384;
#else

}eepromtype16384;
#endif

/*----------------------------------------------------------*/

#ifdef	EEPROM_16384_REQUIRED

typedef union  {

	eepromtype1024	_1024;
	eepromtype4096	_4096;
	eepromtype16384	_16384;

} eepromtype;

#else	/*	EEPROM_16384_REQUIRED	*/

#ifdef	EEPROM_4096_REQUIRED

typedef union  {

	eepromtype1024	_1024;
	eepromtype4096	_4096;

} eepromtype;

#else	/*	EEPROM_4096_REQUIRED	*/

typedef union  {

	eepromtype1024	_1024;

} eepromtype;

#endif	/*	EEPROM_4096_REQUIRED	*/

#endif	/*	EEPROM_16384_REQUIRED	*/

/*----------------------------------------------------------*/

#ifndef __WIN_95__
    #ifdef	__DOS_16__
		#if		(sizeof(eepromtype1024)!=(CS_EEPROM_REGISTERS_1024*2))
			eeprom1024 structure total size is bad
		#endif
		#if		(sizeof(eepromtype4096)!=(CS_EEPROM_REGISTERS_4096*2))
			eeprom4096 structure total size is bad
		#endif
		#if		(sizeof(eepromtype16384)!=(CS_EEPROM_REGISTERS_16384*2))
			eeprom16384 structure total size is bad
		#endif
	#endif /* __DOS_16__ */
#endif /* __WIN_95__ */

/*----------------------------------------------------------*/

/*	Routines that handle EEPROM functionality.	*/

uInt16 GAGEAPI	cs_eeprom_read (uInt16 addr);
void   GAGEAPI	cs_eeprom_write_enable (void);
void   GAGEAPI	cs_eeprom_write (uInt16 addr, uInt16 data);
void   GAGEAPI	cs_eeprom_write_all (uInt16 data);
void   GAGEAPI	cs_eeprom_write_disable (void);
uInt16 GAGEAPI	cs_eeprom_protect_read (void);
void   GAGEAPI	cs_eeprom_protect_enable (void);
void   GAGEAPI	cs_eeprom_protect_clear (void);
void   GAGEAPI	cs_eeprom_protect_write (uInt16 addr);
void   GAGEAPI	cs_eeprom_protect_disable (void);
int16  GAGEAPI	cs_eeprom_read_structure (uInt16 far *bits, eepromtype far *eeprom);
int16  GAGEAPI	cs_eeprom_write_structure (uInt16 bits, eepromtype far *eeprom);

/*----------------------------------------------------------*/

int16  GAGEAPI	cs_eeprom_detect_size_mask_protect (uInt16 far *addr_size, uInt16 far *addr_mask, uInt16 far *protect);
void   GAGEAPI	cs_eeprom_calculate_check_sum (eepromtype far *eeprom);
void   GAGEAPI	cs_eeprom_default_contents_1024 (eepromtype far *eeprom, uInt16 board_type, uInt16 memory_size);
void   GAGEAPI	cs_eeprom_default_contents_4096 (eepromtype far *eeprom, uInt16 board_type, uInt16 memory_size);
void   GAGEAPI	cs_eeprom_default_contents_16384 (eepromtype far *eeprom, uInt16 board_type, uInt16 memory_size);
void   GAGEAPI	cs_eeprom_clear_contents_to_ff (uInt16 bits);
int16  GAGEAPI	cs2125_interpret_eeprom (void);
int16  GAGEAPI	cs8012_interpret_eeprom (void);
int16  GAGEAPI	cs12100_interpret_eeprom (void);
int16  GAGEAPI  cs3200_interpret_eeprom (void);
int16  GAGEAPI  cs82g_interpret_eeprom (void);

/*----------------------------------------------------------*/

#endif /* __EEPROM_H__ */

/*	End of EEPROM.H.	*/

