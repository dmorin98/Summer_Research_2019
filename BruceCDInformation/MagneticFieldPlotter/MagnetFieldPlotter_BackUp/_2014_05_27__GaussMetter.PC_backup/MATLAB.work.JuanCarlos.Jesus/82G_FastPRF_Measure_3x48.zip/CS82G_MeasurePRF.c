/*************************************************************
*	CS82G_MeasurePRF.C			Copyright (c) 2001.  * 	
*										Gage Applied Inc.	 *
*                                       10/26/01             *     										
**************************************************************/

#define	STRICT

#include <io.h>
#include <direct.h>
#include "whichdrv.h"
#include <FCNTL.H>
#include <SYS\STAT.H>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include "CS82G_MeasurePRF.h"
#include "app_supp.c" 


/*#ifndef _WIN32
#include "timers.h"
#else
#define timing(x) Sleep(x/10)
#endif */

 
/****************************\
*                           *
*       GLOBAL DEFINITIONS. *
*       =================== *
*                           *
\***************************/


#define	TRIG_TIMEOUT    100000  //How long to wait for a trigger (in ms).
#define	BUSY_TIMEOUT    100000  //How long to wait for capture to finish (in ms).
#define GAGE_POWER_ON	1		//Turns the ADC Power ON
#define GAGE_POWER_OFF	0		//Turns the ADC Power OFF
#define FILE_SAVE		1		//Writes the data to SIG file. When set to 0, does not write to sig file
#define DEBUG_MODE		0		//FOr more complete info in Timings.dat
#define NRECORDS		100	//Number of Records (each record is board.depth length each)
#define MAX				10		//Number of Strings to display data
#define TIME_MULT		1000	//Convert time to milli seconds


uInt8 *chan_a_8[NRECORDS];
uInt8 *chan_b_8[NRECORDS];
int16 *chan_a_12[NRECORDS];
int16 *chan_b_12[NRECORDS];

#include "diskhead.h"
static disk_file_header header;

#define	RK_LF		0x0a	/*  ASCII "lf" character, ^J.  */
#define	RK_CR		0x0d	/*  ASCII "cr" character, ^M.  */
#define	RK_C_Z		0x1a	/*  MS-DOS ASCII END OF FILE MARKER, ^Z.  */

//char string[15], filename_s1[256], filename_s2[256]; filename_a[256], filename_b[256];
 

/*-------------------------------------------------------------------------*/


void	board_settings(void)
{
/*	This routine is used to set the values in the board structure, defined in STRUCTS.H
	To change one of the hardware parameters, simply change the value of the field in this
	routine.
*/	
	external_clock_in_use = 0;
	external_clock_rate = 10000000.0F;

	board.source	=	GAGE_CHAN_A;
	board.opmode	=	GAGE_SINGLE_CHAN;
	board.srindex	=	best_sample_rate (board_info->board_type, board.opmode, external_clock_in_use);
	board.depth		=	GAGE_POST_16K;
	board.slope		=	GAGE_POSITIVE;
	board.level		=	128;

	board.range_a	=	GAGE_PM_1_V;
	board.range_b	=	GAGE_PM_1_V;
	board.range_e	=	GAGE_PM_5_V;

	board.couple_a	=	GAGE_DC;
	board.couple_b	=	GAGE_DC;
	board.couple_e	=	GAGE_DC;

	board.imped_a	=	GAGE_1_MOHM_INPUT;
	board.imped_b	=	GAGE_1_MOHM_INPUT;

	board.diff_in_a	=	0;			 /* only for CS1602 board */
	board.diff_in_b	=	0;			 /* only for CS1602 board */

}	/*	End of board_settings ()	*/

/*-------------------------------------------------------------------------*/

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)

{

 	// Timing Variables
	
	LARGE_INTEGER	lFreq, lCnt;
	double			Freq;
	
	int			ret;
	long		location, trig, start, end;       /* Vars used by paint code.*/
	int			i, j, res = 0;
	int32		starting, ending, trigger;
	int32		points;
	double		ticks;
	char		c = '\n';
	FILE		*stream1, *stream2, *stream3, *stream4;
	int16		bd,channels=1,value_a,value_b;
	uInt32		offset_1,offset_2;
	uInt32		offset_a[NRECORDS],offset_b[NRECORDS];
	uInt16		mode_options;
	uInt8		value_a_8, value_b_8;
	int32		Start_time, End_time, Total_time;
	float		Average_PRI;

	// Array of pointers to strings to be displayed

	char		*List[MAX] = {"Bef_Capture", "Bef_Trigger", "Bef_Busy","Bef_Calculate", \
		                      "Bef_Transfer", "Bef_File_Append", "Aft_File_Append"};

	// Variables using QueryPerformanceCounter

	double		T_Start_Capture[NRECORDS], T_Trigger[NRECORDS];
	double		T_Busy[NRECORDS], T_Calculate_Address[NRECORDS];
	double		T_Transfer[NRECORDS], T_File_Append[NRECORDS], T_Total[NRECORDS];
	double		T_Bef_Start_Cap, T_Aft_Start_Cap, T_Bef_Trig, T_Aft_Trig;
	double		T_Bef_Busy, T_Aft_Busy, T_Bef_Calc, T_Aft_Calc;
	double		T_Bef_Trans, T_Aft_Trans, T_Bef_Append, T_Aft_Append, sum;

	
	/*	Initializing the CompuScope driver and hardware.	*/

 	if ((ret = InitBoard ()) != 0)
		return (FALSE);

/*  Displaying the sample program version. */
	
	wsprintf (str, "\nThis Program supports the operation of A SINGLE CompuScope Board\n");
	wsprintf (str, "%s\nConnect a +/- 1 Volt signal with a frequency of 1 MHz or more\n",str);
		wsprintf (str, "%sto Channel 1 of your CompuScope.\n",str);
	wsprintf (str, "%s\nThe Program will measure the maximum possible \nPulse Repeat Frequency (PRF) for your CompuScope in this PC\n",str);
	MessageBox (NULL, str, "CS82G_MeasurePRF", MB_OK);

/*  ACQUIRE AND TRANSFER TO DISK  */
/*	============================  */	
	
/*	Verify the board structure for the current CompuScope card.	*/
 
	gage_get_driver_info (board_info);

/*  This routine provides an easy access to board settings that are
	required in order to prepare the compuScope boards for data
	capture.*/

	board_settings();

/*	Send the values set in the board_settings routine to the hardware. */
	SetBoard ();
	
	/*  Allocate Buffers. */

	// Initialize before assignment

	for (i = 0; i<NRECORDS; i++)
	{
		chan_a_8[i]  == NULL;
		chan_b_8[i]  == NULL;
		chan_a_12[i] == NULL;
		chan_b_12[i] == NULL;
	} 

	// Start Allocating

	if (board_info->sample_bits == 8) /* 8 bit board */
	{
		if (board.opmode == GAGE_SINGLE_CHAN) /*8 bit boards, single channel */
		{
			// Get a large buffer (size = depth*NRECORDS)

			for (i = 0; i<NRECORDS; i++)
			{
			
			chan_a_8[i] = (uInt8 *)malloc(board.depth + board_info-> user_buffer_padding);
				if (chan_a_8[i] == NULL)      
				{
					wsprintf (str, "Unable to allocate memory");
					MessageBox(NULL,str,"Error",MB_OK);
					exit(1);
				}
			}
		}
		else  /*8 bit boards, dual channel */
		{
			
			for (i = 0; i<NRECORDS; i++)
			{
				chan_a_8[i] = (uInt8 *)malloc(board.depth + board_info-> user_buffer_padding);
				if (chan_a_8[i] == NULL)      
				{
					wsprintf (str, "Unable to allocate memory");
					MessageBox(NULL,str,"Error",MB_OK);
					exit(1);
				}
			}

			for (i = 0; i<NRECORDS; i++)
			{
			
				chan_b_8[i] = (uInt8 *)malloc(board.depth + board_info-> user_buffer_padding);
				if (chan_b_8[i] == NULL)      
				{
					wsprintf (str, "Unable to allocate memory");
					MessageBox(NULL,str,"Error",MB_OK);
					exit(1);
				}
			}
		}
	}
	else  /* 12,16 bit boards */
	{
		if (board.opmode == GAGE_SINGLE_CHAN) /* Single channel */
		{		
			for (i = 0; i<NRECORDS; i++)
			{
			
				chan_a_12[i] = (int16 *) malloc((board.depth* 2) + board_info-> user_buffer_padding);
				if (chan_a_12[i] == NULL)
				{
					wsprintf(str, "Cannot allocate memory ");
					MessageBox(NULL, str,"Error", MB_OK);
					exit(1);
				}
			}
		}
		else /* Dual Channel */	
		{
			for (i = 0; i<NRECORDS; i++)
			{
			
				chan_a_12[i] = (int16 *) malloc((board.depth* 2) + board_info-> user_buffer_padding);
				if (chan_a_12[i] == NULL)
				{
					wsprintf(str, "Cannot allocate memory ");
					MessageBox(NULL, str,"Error", MB_OK);
					exit(1);
				}			
				chan_b_12[i] = (int16 *) malloc((board.depth* 2) + board_info-> user_buffer_padding);
				if (chan_b_12[i] == NULL)
				{
					wsprintf(str, "Cannot allocate memory ");
					MessageBox(NULL, str,"Error", MB_OK);
					exit(1);
				}
			}
		}
	}

/*	Select appropriate board */

	bd = 0;
	gage_select_board((int16)(bd + 1));

	// Start Acquisition Loop

	// First turn the ADC power ON

	gage_power_control(GAGE_POWER_ON);

	Start_time = GetTickCount();

//*****************************************************************************//
	
	for (i = 0; i<NRECORDS; i++)

	{
		
/*	Start the data acquisition.	The gage_start_capture routine should have a parameter of
	1 for a software trigger and 0 elsewise.	*/

	/* Get time before Capture*/

	QueryPerformanceFrequency(&lFreq);
	Freq = (double)lFreq.LowPart;

	QueryPerformanceCounter(&lCnt);

	T_Bef_Start_Cap = lCnt.LowPart;

	gage_init_clock();

	gage_get_data();

	//gage_start_capture((int16)(board.source == GAGE_SOFTWARE));

/*	When is the acquisition complete.	*/

/*	Check to see if a trigger has occurred.  If one has not occurred within the specified
	amount of ticks, force one by calling gage_force_capture.  If the trigger signal is slow,
	the value of the constant, TRIG_TIMEOUT, should be increased.	It is not necessary to
	have a trigger timeout.	*/

	QueryPerformanceCounter(&lCnt);

	T_Aft_Start_Cap = lCnt.LowPart;

	T_Start_Capture[i]= TIME_MULT*(T_Aft_Start_Cap - T_Bef_Start_Cap)/Freq;

	ticks = GetTickCount();

	//QueryPerformanceFrequency(&lFreq);
	//Freq = (double)lFreq.LowPart;

	QueryPerformanceCounter(&lCnt);

	T_Bef_Trig = lCnt.LowPart;

	//T_Bef_Trig = T_Aft_Start_Cap;

	while (!gage_triggered())
	{
		if (GetTickCount() >= ticks + TRIG_TIMEOUT)  
		{
			gage_force_capture(board.source);
			/*  Display force trigger message. */
			wsprintf (str, "\nNo trigger occurred, software trigger supplied!.");
			MessageBox (NULL, str, "NO TRIGGER", MB_OK | MB_ICONEXCLAMATION);
		}
	}
	
/*	Check to see if the acquisition is complete.  If it is not within the specified
	amount of ticks, abort by calling gage_abort_capture.  For slow sample rates, the value
	of the timeout 	constant, BUSY_TIMEOUT, should be increased. It is not necessary to have
	a busy timeout.	*/

	QueryPerformanceCounter(&lCnt);

	T_Aft_Trig = lCnt.LowPart;

	T_Trigger[i]= TIME_MULT*(T_Aft_Trig - T_Bef_Trig)/Freq;
	
	ticks = GetTickCount(); 

	/* Time Before Busy*/

	//QueryPerformanceFrequency(&lFreq);
	//Freq = (double)lFreq.LowPart;

	QueryPerformanceCounter(&lCnt);

	T_Bef_Busy = lCnt.LowPart;

	while (gage_busy ()) 
	{
		if (GetTickCount() > ticks + BUSY_TIMEOUT) 
		{
			gage_abort_capture (board.source);
			
			/*  Display acquisition abort message. */
			wsprintf (str, "\nCapture aborted, file not saved!.");
			MessageBox (NULL, str, "ABORTED", MB_OK | MB_ICONEXCLAMATION);
			
		}
	}

	QueryPerformanceCounter(&lCnt);

	T_Aft_Busy = lCnt.LowPart;

	T_Busy[i]= TIME_MULT*(T_Aft_Busy - T_Bef_Busy)/Freq;
	
	// Capture complete. Compute addresses 
	/*  Acquisition complete. Saving the CompuScope data to SIG file */
	
/*	Read the addresses for the current capture into variables.  */

	/* Time Before Calculate Addresses*/

	//QueryPerformanceFrequency(&lFreq);
	//Freq = (double)lFreq.LowPart;

	QueryPerformanceCounter(&lCnt);

	T_Bef_Calc = lCnt.LowPart;
	
	gage_calculate_addresses (GAGE_CHAN_A, board.opmode, sample_rate_table[board.srindex].sr_calc,
    			   			  &trigger, &starting, &ending); 
    
/*	We'll start reading at the trigger address.  To read from before or after the trigger address,
	set the location variable to the proper value, ie.  trigger - 100. */
	
	QueryPerformanceCounter(&lCnt);

	T_Aft_Calc = lCnt.LowPart;

	T_Calculate_Address[i]= TIME_MULT*(T_Aft_Calc - T_Bef_Calc)/Freq;
	
	location = trigger;   
	trig = trigger;
	start = starting;
	end = ending;
	points = board.depth;

/*****************************************************************************/	
/*	Select the right board, board numbers start at 1 */
/*****************************************************************************/

	bd = 0;
	gage_select_board((int16)(bd + 1));
	

		if (board_info->sample_bits == 8) /* 8 bit board */
		{
			if (board.opmode ==  GAGE_SINGLE_CHAN)
			{

				/* Time Before Transfer*/

				QueryPerformanceCounter(&lCnt);

				T_Bef_Trans = lCnt.LowPart;

				offset_1 = gage_transfer_buffer_3(location,GAGE_CHAN_A,chan_a_8[i], points);
			
				offset_a[i] = offset_1;
				
				/* Time After Transfer*/
				
				QueryPerformanceCounter(&lCnt);

				T_Aft_Trans = lCnt.LowPart;

				T_Transfer[i]= TIME_MULT*(T_Aft_Trans - T_Bef_Trans)/Freq;
			}
			else
			{
				
				/* Time Before Transfer*/
				
				QueryPerformanceCounter(&lCnt);

				T_Bef_Trans = lCnt.LowPart;
				
				offset_1 = gage_transfer_buffer_3(location,GAGE_CHAN_A,chan_a_8[i], points);
				offset_2 = gage_transfer_buffer_3(location,GAGE_CHAN_B,chan_b_8[i], points);
			
				offset_a[i] = offset_1;
				offset_b[i] = offset_2;
				
				/* Time After Transfer*/
				
				QueryPerformanceCounter(&lCnt);

				T_Aft_Trans = lCnt.LowPart;

				T_Transfer[i]= TIME_MULT*(T_Aft_Trans - T_Bef_Trans)/Freq;
			}
		}
		else   /* 12, 16 bit boards */
		{
			if (board.opmode == GAGE_SINGLE_CHAN)
			{ 
				/* Time Before Transfer*/

				QueryPerformanceCounter(&lCnt);

				T_Bef_Trans = lCnt.LowPart;
				
				offset_1 = gage_transfer_buffer_3 (location, GAGE_CHAN_A, chan_a_12[i],points);
				offset_1 /= (board_info->sample_bits +7)/8;

				offset_a[i] = offset_1;
			
				/* Time After Transfer*/
				
				QueryPerformanceCounter(&lCnt);

				T_Aft_Trans = lCnt.LowPart;

				T_Transfer[i]= TIME_MULT*(T_Aft_Trans - T_Bef_Trans)/Freq;
			}
			else  
			{
				/* Time Before Transfer*/

				QueryPerformanceCounter(&lCnt);

				T_Bef_Trans = lCnt.LowPart;
				
				offset_1 = gage_transfer_buffer_3 (location, GAGE_CHAN_A, chan_a_12[i], points);
				offset_1 /= (board_info->sample_bits +7)/8;
				offset_2 = gage_transfer_buffer_3 (location, GAGE_CHAN_B, chan_b_12[i], points);
				offset_2 /= (board_info->sample_bits +7)/8;

				offset_a[i] = offset_1;
				offset_b[i] = offset_2;
			
				/* Time After Transfer*/
				
				QueryPerformanceCounter(&lCnt);

				T_Aft_Trans = lCnt.LowPart;

				T_Transfer[i]= TIME_MULT*(T_Aft_Trans - T_Bef_Trans)/Freq;
			}
		}
		
}	/* End i */

// Log on the end time, Perform calculations

	End_time = GetTickCount();

	Total_time = End_time - Start_time;

	Average_PRI = (float)Total_time/(float)NRECORDS;

	// Turn the ADC power off

	gage_power_control(GAGE_POWER_OFF);

/*	Open file(s) */

	if (board.opmode == GAGE_SINGLE_CHAN)
	{	
		stream1 = fopen("FAST_PRF_OUTPUT_CH1.SIG", "wb"); 
	}
	else                                                                                                                                
	{                                                                                                                                   
			
		stream2 = fopen( "FAST_PRF_OUTPUT_CH1.SIG", "wb" );	                                                                                            
		stream3 = fopen( "FAST_PRF_OUTPUT_CH2.SIG", "wb" );                                                                                             
	}	 	

/*	Write the header to the file

	/* file_version */
	for (i = 0; i < DISK_FILE_FILEVERSIZE; i++)
		header.file_version[i] = '\0';
	strcpy(header.file_version,FILE_VERSION);

	/* crlf1, crlf2, crlf3 */
	header.crlf1 = header.crlf2 = header.crlf3 = (RK_LF << 8) | RK_CR;

	/* name */
	for (i = 0; i < DISK_FILE_CHANNAMESIZE; i++)
		header.name[i] = '\0';
	strcpy(header.name, "FAST_PRF");

	/* comment */
	for (i = 0; i < DISK_FILE_COMMENT_SIZE; i++)
		header.comment[i] = '\0';
	strcpy(header.comment, "Save GageScope File Format.");
	 
	/* control_z */
	header.control_z = RK_C_Z;

	/* sample_rate_index */
	header.sample_rate_index = calc_sample_rate_index (board_info->rate, board_info->multiplier);
	   
	/* board_type */
	header.board_type = board_info->board_type;

	/* operation_mode */
	header.operation_mode = GAGE_DUAL_CHAN;

	if ((header.board_type == GAGE_ASSUME_CS8500) || (header.board_type == GAGE_ASSUME_CS3200) || (header.board_type == GAGE_ASSUME_CS1016))
		header.operation_mode = GAGE_DUAL_CHAN;
	
	/* trigger_depth */
	header.trigger_depth = board_info->trigger_depth;
	
	/* trigger_slope */
	header.trigger_slope = board_info->trigger_slope;

	/* trigger_source */
	header.trigger_source = board_info->trigger_source;

	/* trigger_level */
	header.trigger_level = board_info->trigger_level;

	/* captured_gain */
   	header.captured_gain = board_info->gain_a;
	 
	/* captured_coupling */
	header.captured_coupling = board_info->coupling_a;

	/* current_mem_ptr */
	header.current_mem_ptr = 0;
	
	/* starting_address */
	header.starting_address = 0;

	/* trigger_address */
	header.trigger_address = 0;
	 
	/* ending_address */
	header.ending_address = board.depth - 1;
	
	/*sample_depth */
	header.sample_depth = board.depth*NRECORDS;
	
	/* trigger_time */
	header.trigger_time = 0;

	/* trigger_date */
	header.trigger_date = 0;

	/* trigger_coupling */
	header.trigger_coupling = board_info->coupling_ext;

	/* trigger_gain */
	header.trigger_gain = board_info->gain_ext;

	/* probe */
	header.probe = 0;

	/* inverted_data */
	header.inverted_data = 0;

	/* resolution_12_bits */
	//header.resolution_12_bits = (int16)(board_info->sample_bits >= 12);

	header.resolution_12_bits = 0;

	/* multiple_record */
	// 2 for software mulrec
	//header.multiple_record = 2;
	// 1 for Hardware mulrec
	// 0 for Normal records
	header.multiple_record = 2;

	/* trigger_probe */
	header.trigger_probe = 0;

	/* sample_offset */
	//header.sample_offset = (int16)(board_info->sample_offset_32);
	header.sample_offset = 127;

	/* sample_offset_32 */
	//header.sample_offset_32 = board_info->sample_offset_32;


	/* sample_resolution */
	//header.sample_resolution = (int16)(board_info->sample_resolution_32);

	header.sample_resolution = 128;

	/* sample_resolution_32 */
	//header.sample_resolution_32 = board_info->sample_resolution_32;
	//header.sample_resolution_32 = 0;

	/* sample_bits */
	header.sample_bits = board_info->sample_bits;

	/* extended_trigger_time */
	header.extended_trigger_time = 0;

	/* imped_a */
	header.imped_a = board_info->imped_a;

	/* imped_b */
	header.imped_b = board_info->imped_b;

	/* file_options */
	header.file_options = 0;
	if (board_info->external_clock_adjust)
		header.file_options |= FILE_OPTIONS_EXT_CLOCK_ADJUST;
	if (board_info->ee_options & EEPROM_OPTIONS_MULREC_ADJUST)
		header.file_options |= FILE_OPTIONS_MULREC_ADJUST;
	
	/* record_depth */
	header.record_depth = 0;
	
	/* version */
	header.version = board_info->board_version;

	/* eeprom_options */
	header.eeprom_options = board_info->ee_options;;

	/* external_tbs and external_clock_rate */
	mode_options = (uInt16)(((((header.board_type & GAGE_ASSUME_CS8012_TYPE) && (header.version  & 0x0001)) != 0) * GAGE_FAST_RAM_ADJUST)
						|  (((( header.board_type & GAGE_ASSUME_CS8012_TYPE) && (header.version >= 0x0200)) != 0) * GAGE_X012X_VERS_ADJUST)
						|  (((( header.board_type == GAGE_ASSUME_CS8500) && (header.version >= 0x0013)) != 0) * GAGE_VERSION_ADJUST)
						|  (((( header.eeprom_options & EEPROM_OPTIONS_MULREC_ADJUST)!= 0) * GAGE_MODE_MULREC_ADJUST))
						|  (((( header.eeprom_options & EEPROM_OPTIONS_X1_CLOCK)!= 0) * GAGE_X1_CLOCK_ADJUST))
						|  (((( board_info->external_clock_adjust)!= 0) * GAGE_MODE_EXT_CLK_ADJ)));

	if (external_clock_in_use) 
	{
		if (mode_options & GAGE_X1_CLOCK_ADJUST)
			header.external_clock_rate = board_info->external_clock_rate;
		else
			header.external_clock_rate = board_info->external_clock_rate / (1 + (board_info->mode == GAGE_DUAL_CHAN));
		if (header.external_clock_rate)
			header.external_tbs = 1000000000.0F / header.external_clock_rate;
		else
			header.external_tbs = 1;
	}
	else
	{
		header.external_tbs = 0.0F;
		header.external_clock_rate = 0.0F;
	}

	if (board.opmode == GAGE_SINGLE_CHAN)
		fwrite(&header, sizeof(disk_file_header), 1, stream1);
	else
	{
		fwrite(&header, sizeof(disk_file_header), 1, stream2);
		fwrite(&header, sizeof(disk_file_header), 1, stream3);
	}

	// Save data to files

	/* Start Writing to the files. Write to files if FILE_SAVE is 1. When this parameter is set to 0, skip writing to file */ 

	for (i = 0; i<NRECORDS; i++)
	{
	
		if (FILE_SAVE == 1)
		{

			if (board_info->sample_bits == 8) /* 8 bit board */
			{
				if (board.opmode == GAGE_SINGLE_CHAN)
				{
			
					/* Time Before File Append*/

					QueryPerformanceCounter(&lCnt);

					T_Bef_Append = lCnt.LowPart;

						for (j = 0; j < points; j++) 
						{	
							value_a_8 = chan_a_8[i][offset_a[i]+j];
							fwrite(&value_a_8, sizeof(value_a_8), 1, stream1);	
						}

					/* Time After File Append*/
				
					QueryPerformanceCounter(&lCnt);

					T_Aft_Append = lCnt.LowPart;

					T_File_Append[i]= TIME_MULT*(T_Aft_Append - T_Bef_Append)/Freq;
				}
				else
				{
					/* Time Before File Append*/

					QueryPerformanceCounter(&lCnt);

					T_Bef_Append = lCnt.LowPart;
			
					for (j = 0; j < points; j++) 
					{
						value_a_8 = chan_a_8[i][offset_a[i]+j];
						fwrite(&value_a_8, sizeof(value_a_8), 1, stream2);
				
						value_b_8 = chan_b_8[i][offset_b[i]+j];
						fwrite(&value_b_8, sizeof(value_b_8), 1, stream3);
					}

					/* Time After File Append*/
				
					QueryPerformanceCounter(&lCnt);

					T_Aft_Append = lCnt.LowPart;

					T_File_Append[i]= TIME_MULT*(T_Aft_Append - T_Bef_Append)/Freq;	
				} 	
			}
			else /* 12, 16 bit boards */
			{
				if (board.opmode == GAGE_SINGLE_CHAN)
				{
					/* Time Before File Append*/

					QueryPerformanceCounter(&lCnt);

					T_Bef_Append = lCnt.LowPart;
				
					for (j = 0; j < points; j++) 
					{	
						value_a = chan_a_12[i][offset_a[i]+j];
						fwrite(&value_a, sizeof(value_a), 1, stream1);	
					}

					/* Time After File Append*/
				
					QueryPerformanceCounter(&lCnt);

					T_Aft_Append = lCnt.LowPart;

					T_File_Append[i]= TIME_MULT*(T_Aft_Append - T_Bef_Append)/Freq;
				}
				else
				{
					/* Time Before File Append*/

					QueryPerformanceCounter(&lCnt);

					T_Bef_Append = lCnt.LowPart;
			
					for (j = 0; j < points; j++) 
					{
						value_a = chan_a_12[i][offset_a[i]+j];
						fwrite(&value_a, sizeof(value_a), 1, stream2);
				
						value_b = chan_b_12[i][offset_b[i]+j];
						fwrite(&value_b, sizeof(value_b), 1, stream3);
					}

					/* Time After File Append*/
				
					QueryPerformanceCounter(&lCnt);

					T_Aft_Append = lCnt.LowPart;

					T_File_Append[i]= TIME_MULT*(T_Aft_Append - T_Bef_Append)/Freq;
				} 			
			}
		}		
	}

	// End Saving data to files

sum=0;
T_Bef_Start_Cap=0;
T_Bef_Trig=0;
T_Bef_Busy=0;
T_Bef_Calc=0;
T_Bef_Trans=0;

for (j=0;j<NRECORDS; j++) 

{

	
	sum = sum + T_Start_Capture[j] + T_Trigger[j] + T_Busy[j] + T_Calculate_Address[j] + T_Transfer[j];

	T_Bef_Start_Cap+=T_Start_Capture[j];
T_Bef_Trig+=T_Trigger[j];
T_Bef_Busy+= T_Busy[j];
T_Bef_Calc+=T_Calculate_Address[j];
T_Bef_Trans+=T_Transfer[j];

}
	
sum = sum/NRECORDS;
T_Bef_Start_Cap/=NRECORDS;
T_Bef_Trig/=NRECORDS;
T_Bef_Busy/= NRECORDS;
T_Bef_Calc/=NRECORDS;
T_Bef_Trans/=NRECORDS;

i= (int) (sum*1000);
j = (int)(1000/sum);


	
	wsprintf (str, "\nCaptured %d Records of %d Points each on %d channels at the maximum sampling rate.\n", NRECORDS, board.depth, (board.opmode));
	wsprintf (str, "%s\n  Average Pulse Handling Time: %d microseconds\n  Max Pulse Repeat Frequency: %d Hz\n",str,i,j);
	wsprintf (str, "%s\nSee Timings.dat file for more details.\n",str);
	wsprintf (str, "%sData are stored SIG files in same folder as executable.\n",str);
	MessageBox (NULL, str, "PRF RESULTS", MB_OK);


	//Write timing data to timings.dat file

	stream4 = fopen("Timings.dat", "w");

	if (DEBUG_MODE == 1)
	{

	fprintf( stream4, " \nPARAMETERS BASED ON GetTickCount() ROUTINE: \n\nFILE SAVE ON \n  \
		\nTotal Number of Records = %d\t \n\nRecord Length= %d\t \n\nTotal Time to Capture, Download and Save %d Records (msec) = %d\n \
		\nPARAMETERS BASED ON HighResolutionCounter: \n\n \
		\nAverage Times (in msec) and those for first 10 records are shown.\n\nIndex \tSt_Capture \tTrigger \tBusyCapture \tCalculate \tTransfer  \tTotal \n\n", \
		NRECORDS, board.depth, NRECORDS, Total_time);




			fprintf( stream4, "\nAVG\t %8.3f\t %8.3f\t %8.3f\t %8.3f\t %8.3f\t %8.3f \t", \
			 T_Bef_Start_Cap, T_Bef_Trig, T_Bef_Busy, T_Bef_Calc, T_Bef_Trans, sum);

		j = 0;
		while (j < 10)
		{
			T_Total[j] = T_Start_Capture[j] + T_Trigger[j] + T_Busy[j] + T_Calculate_Address[j] + T_Transfer[j];

			fprintf( stream4, "\n%2d\t %8.3f\t %8.3f\t %8.3f\t %8.3f\t %8.3f\t %8.3f \t", \
			j+1, T_Start_Capture[j], T_Trigger[j], T_Busy[j], T_Calculate_Address[j], T_Transfer[j],  T_Total[j]);		
		
			j = j+1;
		}

	}
	else
	{
		fprintf( stream4, "\nGage Applied Inc.\n");
		fprintf( stream4, "www.gage-applied.com\n");

		fprintf( stream4, "\nMaximum Pulse Repeat Frequency (PRF) Measurement Utility\n");
		fprintf( stream4, "********************************************************\n");

		fprintf( stream4, "\nTotal Number of Records Captured = %d\n", NRECORDS);
		fprintf( stream4, "Length of each Record Captured = %d\n", board.depth);
		fprintf( stream4, "Number of Channels Acquired = %d\n",board.opmode);
		
		fprintf( stream4, "\nTimings for a single acquisition averaged over all acquisitions\n");
		fprintf( stream4, "\nTime#1 CompuScope Re-Arm Time (milliseconds) = %8.3f\n",T_Bef_Start_Cap);
		fprintf( stream4, "Time#2 CompuScope Trigger Polling Time (milliseconds) = %8.3f\n",T_Bef_Trig);
		fprintf( stream4, "Time#3 Time for CompuScope acquisition to finish (milliseconds) = %8.3f\n",T_Bef_Busy);
		fprintf( stream4, "Time#4 Time for calculation of CompuScope on-board memory addresses (milliseconds) = %8.3f\n",T_Bef_Calc);
		fprintf( stream4, "Time#5 Data Transfer Time (milliseconds) = %8.3f\n",T_Bef_Trans);
		fprintf( stream4, "       Data Transfer Rate (MegaSamples/sec) = %8.3f   (SEE NOTE 2)\n",(board.depth/T_Bef_Trans)/1000.0);
	

		fprintf( stream4, "\n**********************************************************************\n");

		fprintf( stream4, "\nTotal Acquisition Time (Sum of Times #1-5) (milliseconds) = %8.3f\n",sum);
		fprintf( stream4, "MAX Possible PRF (Acquisitions/second) = %8.0f\n",1000/sum);
	fprintf( stream4,     "\n**********************************************************************\n");
		

		fprintf( stream4, "\n\nNOTE 1 -  All Timing Measurements are made using \n");
		fprintf( stream4,      "          MicroSoft Visual C/C++ QueryPerformanceCounter() function.\n");
		fprintf( stream4, "\nNOTE 2 -  PCI Data transfer rates for less than a depth of 10,000 are limited\n");
		fprintf( stream4,   "          DMA controller setup time.  Above this depth, sustained data transfer rates\n");
		fprintf( stream4,   "          of over 80 MegaBytes/second can be achieved.\n");


			

	}
	fclose(stream4);

	// Close the files
	
	if (board.opmode == GAGE_SINGLE_CHAN)
	{
		fclose(stream1);
	}
	else
	{
		fclose(stream2);
		fclose(stream3);
	}

	/* Free Buffers*/

	for (i = 0; i<NRECORDS; i++)
	{

		if (chan_a_12[i] != NULL)
			free (chan_a_12[i]);

		if (chan_b_12[i] != NULL)
			free (chan_b_12[i]);

		if (chan_a_8[i] != NULL)
			free (chan_a_8[i]);
		
		if (chan_b_8[i] != NULL)
			free (chan_b_8[i]);
	}


/*	Success message display */
	//	wsprintf (str, " Acquisition completed. All the channels are saved to SIG data file(s) in the current working directory. ");    
	//	MessageBox(NULL, str, "CS82G_MeasurePRF", MB_OK);	

	return (0);

} /* end of WinMain */
/*-------------------------------------------------------------------*/

int16	calc_sample_rate_index (int16 rate, int16 multiplier)
{
	switch (multiplier)  
	{
	case GAGE_HZ:
		switch (rate)  
		{
		case GAGE_RATE_1:
			return (SRTI_1_HZ);
		case GAGE_RATE_2:
			return (SRTI_2_HZ);
		case GAGE_RATE_5:
			return (SRTI_5_HZ);
		case GAGE_RATE_10:
			return (SRTI_10_HZ);
		case GAGE_RATE_20:
			return (SRTI_20_HZ);
		case GAGE_RATE_50:
			return (SRTI_50_HZ);
		case GAGE_RATE_100:
			return (SRTI_100_HZ);
		case GAGE_RATE_200:
			return (SRTI_200_HZ);
		case GAGE_RATE_500:
			return (SRTI_500_HZ);
		}	/*	End of switch (rate).	*/
		break;
	case GAGE_KHZ:
		switch (rate)  
		{
		case GAGE_RATE_1:
			return (SRTI_1_KHZ);
		case GAGE_RATE_2:
			return (SRTI_2_KHZ);
		case GAGE_RATE_5:
			return (SRTI_5_KHZ);
		case GAGE_RATE_10:
			return (SRTI_10_KHZ);
		case GAGE_RATE_20:
			return (SRTI_20_KHZ);
		case GAGE_RATE_50:
			return (SRTI_50_KHZ);
		case GAGE_RATE_100:
			return (SRTI_100_KHZ);
		case GAGE_RATE_200:
			return (SRTI_200_KHZ);
		case GAGE_RATE_500:
			return (SRTI_500_KHZ);
		case GAGE_RATE_2500:
			return (SRTI_2_5_MHZ);
		case GAGE_RATE_12500:
			return (SRTI_12_5_MHZ);
		}	/*	End of switch (rate).	*/
		break;
	case GAGE_MHZ:
		switch (rate)  
		{
		case GAGE_RATE_1:
			return (SRTI_1_MHZ);
		case GAGE_RATE_2:
			return (SRTI_2_MHZ);
		case GAGE_RATE_5:
			return (SRTI_5_MHZ);
		case GAGE_RATE_10:
			return (SRTI_10_MHZ);
		case GAGE_RATE_20:
			return (SRTI_20_MHZ);
		case GAGE_RATE_25:
			return (SRTI_25_MHZ);
		case GAGE_RATE_30:
			return (SRTI_30_MHZ);
		case GAGE_RATE_40:
			return (SRTI_40_MHZ);
		case GAGE_RATE_50:
			return (SRTI_50_MHZ);
		case GAGE_RATE_60:
			return (SRTI_60_MHZ);
		case GAGE_RATE_65:
			return (SRTI_65_MHZ);
		case GAGE_RATE_80:
			return (SRTI_80_MHZ);
		case GAGE_RATE_100:
			return (SRTI_100_MHZ);
		case GAGE_RATE_120:
			return (SRTI_120_MHZ);
		case GAGE_RATE_125:
			return (SRTI_125_MHZ);
		case GAGE_RATE_130:
			return (SRTI_130_MHZ);
		case GAGE_RATE_150:
			return (SRTI_150_MHZ);
		case GAGE_RATE_200:
			return (SRTI_200_MHZ);
		case GAGE_RATE_250:
			return (SRTI_250_MHZ);
		case GAGE_RATE_300:
			return (SRTI_300_MHZ);
		case GAGE_RATE_500:
			return (SRTI_500_MHZ);
		}	/*	End of switch (rate).	*/
		break;
	case GAGE_GHZ:
		switch (rate)  
		{
		case GAGE_RATE_1:
			return (SRTI_1_GHZ);
		case GAGE_RATE_2:
			return (SRTI_2_GHZ);
		case GAGE_RATE_4:
			return (SRTI_2_5_GHZ);
		case GAGE_RATE_5:
			return (SRTI_5_GHZ);
		case GAGE_RATE_8:
			return (SRTI_8_GHZ);
		case GAGE_RATE_10:
			return (SRTI_10_GHZ);
		}	/*	End of switch (rate).	*/
		break;
	case GAGE_EXT_CLK:
		return (SRTI_EXTERNAL);
	}	/*	End of switch (multiplier).	*/
	return (DEFAULT_SAMPLE_RATE_INDEX);

}	/*	End of calc_sample_rate_index ().  */

/*-------------------------------------------------------------------*/



