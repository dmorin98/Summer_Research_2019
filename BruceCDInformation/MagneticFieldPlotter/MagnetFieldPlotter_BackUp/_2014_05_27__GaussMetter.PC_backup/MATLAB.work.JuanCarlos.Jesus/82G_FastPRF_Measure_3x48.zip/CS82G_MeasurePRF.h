/*************************************************************
*		A2D_PAGED_TRANSFER.H				 Version 1.00.00 *
*       Copyright (c) 2000 Gage Applied Sciences Inc.        *
*       Last Update:                 10/01/2000              *
\*************************************************************/
#include <windows.h>
#include <string.h>


void	board_settings(void);
int		mem_read_routine(void);
int		tranfer_buffer_routine(void);
int16	calc_sample_rate_index (int16 rate, int16 multiplier);
